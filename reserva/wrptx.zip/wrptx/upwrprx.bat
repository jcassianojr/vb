copy wrptx.exe wrpti.exe
copy wrptx.exe wrptd.exe
copy wrptx.exe wrptf.exe
copy wrpt.ini wrpti.ini
copy wrpt.ini wrptf.ini
copy wrpt.ini wprtd.ini
