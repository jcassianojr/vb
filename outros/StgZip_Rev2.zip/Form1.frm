VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Zip with IStorage Demo"
   ClientHeight    =   3030
   ClientLeft      =   45
   ClientTop       =   375
   ClientWidth     =   4560
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3030
   ScaleWidth      =   4560
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command4 
      Caption         =   "Clear List"
      Height          =   300
      Left            =   3525
      TabIndex        =   6
      Top             =   225
      Width           =   1005
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Create Zip File"
      Height          =   495
      Left            =   60
      TabIndex        =   5
      Top             =   2400
      Width           =   1725
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Save As..."
      Height          =   240
      Left            =   3435
      TabIndex        =   4
      Top             =   2265
      Width           =   1050
   End
   Begin VB.TextBox Text1 
      Height          =   315
      Left            =   75
      TabIndex        =   3
      Top             =   1905
      Width           =   4425
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Add Files..."
      Height          =   360
      Left            =   90
      TabIndex        =   1
      Top             =   105
      Width           =   1710
   End
   Begin VB.ListBox List1 
      Height          =   1035
      Left            =   60
      TabIndex        =   0
      Top             =   555
      Width           =   4485
   End
   Begin VB.Label Label1 
      Caption         =   "Save Zip file to:"
      Height          =   225
      Left            =   90
      TabIndex        =   2
      Top             =   1680
      Width           =   1545
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private ifdOpen As FileOpenDialog
Private ifdSave As FileSaveDialog

'Private Type COMDLG_FILTERSPEC
'    pszName As String
'    pszSpec As String
'End Type

Private sFiles() As String
Private nFiles As Long

Private Sub Command1_Click()
Dim psia As IShellItemArray
Dim pEnum As IEnumShellItems
Dim psi As IShellItem

Dim lpFile As Long
Dim pclt As Long
Dim i As Long, k As Long

Dim tFilter() As COMDLG_FILTERSPEC
ReDim tFilter(0)
tFilter(0).pszName = "All Files"
tFilter(0).pszSpec = "*.*"

Set ifdOpen = New FileOpenDialog
With ifdOpen
    .SetTitle "Select files to add to Zip"
    .SetOptions FOS_ALLOWMULTISELECT Or FOS_FILEMUSTEXIST Or FOS_DONTADDTORECENT
    .SetFileTypes 1, VarPtr(tFilter(0).pszName)
    .Show Me.hWnd
    
    .GetResults psia
End With

If (psia Is Nothing) = False Then
    psia.EnumItems pEnum
    
    Do While (pEnum.Next(1, psi, pclt) = S_OK)
        psi.GetDisplayName SIGDN_FILESYSPATH, lpFile
        ReDim Preserve sFiles(nFiles)
        sFiles(nFiles) = LPWSTRtoStr(lpFile)
        List1.AddItem sFiles(nFiles)
        nFiles = nFiles + 1
    Loop
End If

End Sub

Private Sub Command2_Click()
Dim psi As IShellItem
Dim lpFile As Long

Dim tFilter() As COMDLG_FILTERSPEC
ReDim tFilter(0)
tFilter(0).pszName = "Zip Files"
tFilter(0).pszSpec = "*.zip"

Set ifdSave = New FileSaveDialog

With ifdSave
    .SetTitle "Save Zip As..."
    .SetFileTypes 1, VarPtr(tFilter(0).pszName)
    .SetDefaultExtension ".zip"
    .SetOptions FOS_DONTADDTORECENT Or FOS_OVERWRITEPROMPT
    .Show Me.hWnd
    
    .GetResult psi
    
    If (psi Is Nothing) = False Then
        psi.GetDisplayName SIGDN_FILESYSPATH, lpFile
        Text1.Text = LPWSTRtoStr(lpFile)
    End If
End With

    
End Sub

Private Sub Command3_Click()
If (Text1.Text = "") Or (List1.ListCount = 0) Then
    Beep
    Exit Sub
End If
ZipFiles Text1.Text, sFiles
End Sub

Private Sub Command4_Click()
ReDim sFiles(0)
nFiles = 0
End Sub

Private Sub Form_Load()
ReDim sFiles(0)
End Sub
