Attribute VB_Name = "modEnvironment"
Option Explicit

Public Function envRunningInIde() As Boolean
   Static s_InIde As Boolean
   Static s_Checked As Boolean
   
   If Not s_Checked Then
      s_Checked = True
      
      On Error Resume Next
      Debug.Assert 1 / 0
      s_InIde = Err.Number
      On Error GoTo 0
      
      Err.Clear
   End If
   
   envRunningInIde = s_InIde
End Function

Public Function envDebugMode() As Boolean
   If envRunningInIde Then envDebugMode = False  ' Set to false to disable debug mode (better performance, less noisy debug window)
End Function
