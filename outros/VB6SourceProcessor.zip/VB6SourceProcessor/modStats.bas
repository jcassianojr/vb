Attribute VB_Name = "modStats"
Option Explicit

Private mo_StatsCnn As RC6.cConnection
Private mo_StatsVbpTokenTypeIncCmd As RC6.cCommand
Private mo_StatsVbpDeleteByStatsKeyCmd As RC6.cCommand
Private mo_StatsVbpSelectCountByTokenTypeCmd As RC6.cSelectCommand

Private Sub statsInitIfNecessary()
   If mo_StatsCnn Is Nothing Then
      Set mo_StatsCnn = New_C.Connection(":memory:", DBCreateInMemory)
      mo_StatsCnn.Execute "CREATE TABLE vbpstats (statskey TEXT NOT NULL, tokentype INTEGER NOT NULL, count INTEGER)"
      mo_StatsCnn.Execute "CREATE INDEX idx_statskey ON vbpstats (statskey ASC)"
      mo_StatsCnn.Execute "CREATE INDEX idx_tokentype ON vbpstats (tokentype ASC)"
      mo_StatsCnn.Execute "CREATE UNIQUE INDEX uidx_statskeyandtoketype ON vbpstats (statskey ASC, tokentype ASC)"
   
      Set mo_StatsVbpTokenTypeIncCmd = mo_StatsCnn.CreateCommand("INSERT INTO vbpstats (statskey, tokentype, count) VALUES (?,?,1) ON CONFLICT(statskey,tokentype) DO UPDATE SET count=count+1")
      Set mo_StatsVbpDeleteByStatsKeyCmd = mo_StatsCnn.CreateCommand("DELETE FROM vbpstats WHERE statskey=?")
      Set mo_StatsVbpSelectCountByTokenTypeCmd = mo_StatsCnn.CreateSelectCommand("SELECT SUM(count) FROM vbpstats WHERE tokentype=?")
   End If
End Sub

Public Sub statsIncrementVbpTokenTypeCount(ByVal p_StatsKey As String, ByVal p_TokenType As e_VbpType)
   statsInitIfNecessary
   
   With mo_StatsVbpTokenTypeIncCmd
      .SetText 1, p_StatsKey
      .SetInt32 2, p_TokenType
      If Not .Execute Then
         ' This should have succeeded!
         Debug.Assert False
      End If
      .SetAllParamsNull
   End With
End Sub

Public Sub statsRemoveAllByStatsKey(ByVal p_StatsKey As String)
   If stringsIsEmptyOrWhitespaceOnly(p_StatsKey) Then Debug.Assert False: Exit Sub
   If mo_StatsVbpDeleteByStatsKeyCmd Is Nothing Then Exit Sub
   
   With mo_StatsVbpDeleteByStatsKeyCmd
      .SetText 1, p_StatsKey
      If Not .Execute Then
         ' This should have succeeded!
         Debug.Assert False
      End If
      .SetAllParamsNull
   End With
End Sub

Public Function statsCountByTokenType(ByVal p_TokenType As e_VbpTokenType) As Long
   If mo_StatsVbpSelectCountByTokenTypeCmd Is Nothing Then Exit Function
   
   With mo_StatsVbpSelectCountByTokenTypeCmd
      .SetInt32 1, p_TokenType
      
      On Error Resume Next
      statsCountByTokenType = .Execute.Fields(0).Value
      On Error GoTo 0
   End With
End Function

Public Sub statsCleanup()
   Set mo_StatsVbpSelectCountByTokenTypeCmd = Nothing
   Set mo_StatsVbpDeleteByStatsKeyCmd = Nothing
   Set mo_StatsVbpTokenTypeIncCmd = Nothing
   Set mo_StatsCnn = Nothing
End Sub
