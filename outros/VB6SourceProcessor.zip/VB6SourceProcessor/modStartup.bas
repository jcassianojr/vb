Attribute VB_Name = "modStartup"
Option Explicit

Sub Main()
   Dim l_Pcre2Dll As String
   Dim lo_MainForm As frmMain
   
   l_Pcre2Dll = PathAppSystem & "pcre2-16.dll"
   If LoadLibraryW(StrPtr(l_Pcre2Dll)) = 0 Then
      MsgBox "Could not find required DLL: " & l_Pcre2Dll
      Exit Sub
   End If
   
   Set lo_MainForm = New frmMain
   lo_MainForm.Show
End Sub

