Attribute VB_Name = "modApi"
Option Explicit

Public Const FADF_AUTO      As Integer = &H1   'An array that is allocated on the stack.
Public Const FADF_FIXEDSIZE As Integer = &H10  'An array that may not be resized or reallocated.

Public Type SAFEARRAY1D    'Represents a safe array. (One Dimensional)
    cDims      As Integer   'The count of dimensions.
    fFeatures  As Integer   'Flags used by the SafeArray.
    cbElements As Long      'The size of an array element.
    cLocks     As Long      'The number of times the array has been locked without a corresponding unlock.
    pvData     As Long      'Pointer to the data.
    cElements  As Long      'The number of elements in the dimension.
    lLbound    As Long      'The lower bound of the dimension.
End Type                    'https://msdn.microsoft.com/en-us/library/ms221482(v=vs.85).aspx

Public Declare Function VarPtrArray Lib "msvbvm60.dll" Alias "VarPtr" (ByRef ArrayVar() As Any) As Long
Public Declare Sub PutMem4 Lib "msvbvm60.dll" (ByVal addr As Long, ByVal NewVal As Long)

Public Declare Function LoadLibraryW Lib "kernel32" (ByVal lpLibFileName As Long) As Long

