Attribute VB_Name = "modFormat"
Option Explicit

Public Function formatSecondsToHumanReadable(ByVal p_Seconds As Long) As String
   
   Dim l_Mod As Long
   
   If p_Seconds >= 60# Then
      l_Mod = p_Seconds Mod 60
      p_Seconds = p_Seconds \ 60
   
      formatSecondsToHumanReadable = p_Seconds & formatPluralizeWordByCount(" minute", p_Seconds) & _
                                                  IIf(l_Mod > 0, " and " & l_Mod & formatPluralizeWordByCount(" second", l_Mod), "")
   Else
      formatSecondsToHumanReadable = p_Seconds & formatPluralizeWordByCount(" second", p_Seconds)
   End If
End Function

Public Function formatPluralizeWordByCount(ByVal p_Word As String, ByVal p_Count As Long) As String
   ' Takes any word and appends "es" or "s" to it if p_Count<>1
   ' I wasn't sure how to handle negative numbers grammatically, but adding a trailing "es"/"s" sounded more correct to me
   ' "We will have -1 apples" vs. "We will have -1 apple"
   
   ' IMPORTANT!!
   '    This function is incredibly naive, and only reasonably satisfactory for English language "p_Word" parameters,
   '    and only mostly guaranteed to work against the very limited English language vocabulary of this program.
   '    PLEASE DO NOT USE THIS FUNCTION IN YOUR OWN PROGRAMS
   
   Dim l_Ucase As Boolean
   Dim l_LastChar As String
   Dim l_Suffix As String
   
   formatPluralizeWordByCount = p_Word
   
   If p_Count <> 1 Then
      ' We should pluralize
      
      l_LastChar = Right$(p_Word, 1)
      l_Ucase = (LCase$(l_LastChar) <> l_LastChar)
      
      Select Case LCase$(Right$(p_Word, 1))
      Case "s", "x", "z"
         l_Suffix = "es"
      Case Else
         l_Suffix = "s"
      End Select
      
      If l_Ucase Then
         formatPluralizeWordByCount = formatPluralizeWordByCount & UCase$(l_Suffix)
      Else
         formatPluralizeWordByCount = formatPluralizeWordByCount & l_Suffix
      End If
   End If
End Function



