Attribute VB_Name = "modEnums"
Option Explicit

Public Enum e_ErrorCode
   [_err_Base] = vbObjectError + &H1000&
   
   err_NotReady                  ' A class isn't ready to perform an action
   err_UnknownFileExtension      ' Not a VBP or VBG file extension
   err_FileNotVbp                ' File doesn't appear to be a valid VBP
   err_UnsupportedVbpType        ' VBP project type is not supported
   err_TokenValueError           ' Expected something for a VBP or VBG token value, and we didn't get it
   err_SourceFileNotFound        ' Could not locate a source file that was referenced in a VBP/VBG
End Enum

Public Enum e_LogLevel
   loglevel_Information
   loglevel_Important
   loglevel_Warning
   loglevel_Error
End Enum

Public Enum e_RegexMatchType
   regexmt_Match = -3
   regexmt_Pregexmt_Match
   regexmt_PostMatch
   regexmt_Matches
   regexmt_Match1 = 1
   regexmt_Match2
   regexmt_Match3
   regexmt_Match4
   regexmt_Match5
   regexmt_Match6
   regexmt_Match7
   regexmt_Match8
   regexmt_Match9
   regexmt_Match10
   regexmt_Match11
   regexmt_Match12
   regexmt_Match13
   regexmt_Match14
   regexmt_Match15
   regexmt_Match16
   regexmt_Match17
   regexmt_Match18
   regexmt_Match19
   regexmt_Match20
   regexmt_Match21
   regexmt_Match22
   regexmt_Match23
   regexmt_Match24
   regexmt_Match25
   regexmt_Match26
   regexmt_Match27
   regexmt_Match28
   regexmt_Match29
   regexmt_Match30
   regexmt_Match31
End Enum

Public Enum e_StringTrimType
   stringtt_None
   stringtt_Left
   stringtt_Right
   stringtt_Both
End Enum

Public Enum e_StringWhitespaceHandling
   white_LeaveAlone
   white_Trim = 1
   white_Flatten = 2
   white_RemoveAll = 8192
End Enum

