Attribute VB_Name = "modLibs"
Option Explicit

Public Function libRc5Crypt() As RC6.cCrypt
   Static so_Lib As RC6.cCrypt
   
   If so_Lib Is Nothing Then Set so_Lib = New_c.Crypt
   Set libRc5Crypt = so_Lib
End Function

