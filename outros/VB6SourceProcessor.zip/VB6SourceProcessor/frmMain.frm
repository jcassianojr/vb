VERSION 5.00
Object = "{7020C36F-09FC-41FE-B822-CDE6FBB321EB}#1.2#0"; "vbccr18.OCX"
Object = "{B2F499FE-43A9-4238-907E-5740238C61D8}#1.0#0"; "VBFLXGRD18.OCX"
Begin VB.Form frmMain 
   Caption         =   "VB6 Source Processor"
   ClientHeight    =   4740
   ClientLeft      =   60
   ClientTop       =   650
   ClientWidth     =   9720
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.5
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   4740
   ScaleWidth      =   9720
   StartUpPosition =   2  'CenterScreen
   Begin vbccr18.FrameW fraLog 
      Height          =   3610
      Left            =   2550
      TabIndex        =   5
      Top             =   450
      Width           =   2320
      _ExtentX        =   4092
      _ExtentY        =   6368
      Appearance      =   0
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      BorderStyle     =   0
      Begin VBFLXGRD18.VBFlexGrid gridLog 
         Height          =   3160
         Left            =   0
         TabIndex        =   6
         Top             =   420
         Width           =   2290
         _ExtentX        =   4039
         _ExtentY        =   5574
         FixedCols       =   0
         AllowBigSelection=   0   'False
         AllowSelection  =   0   'False
         SelectionMode   =   1
         ScrollTrack     =   -1  'True
         HighLight       =   2
         FocusRect       =   0
         WordWrap        =   -1  'True
         ShowInfoTips    =   -1  'True
      End
      Begin vbccr18.CheckBoxW chkLogImportant 
         Height          =   310
         Left            =   990
         TabIndex        =   8
         Top             =   0
         Width           =   1150
         _ExtentX        =   2028
         _ExtentY        =   547
         Appearance      =   0
         BackColor       =   -2147483643
         ForeColor       =   -2147483640
         Value           =   1
         Caption         =   "I&mportant"
      End
      Begin vbccr18.CheckBoxW chkLogWarn 
         Height          =   310
         Left            =   660
         TabIndex        =   9
         Top             =   0
         Width           =   880
         _ExtentX        =   1552
         _ExtentY        =   547
         Appearance      =   0
         BackColor       =   -2147483643
         ForeColor       =   -2147483640
         Value           =   1
         Caption         =   "&Warning"
      End
      Begin vbccr18.CheckBoxW chkLogError 
         Height          =   310
         Left            =   570
         TabIndex        =   10
         Top             =   0
         Width           =   880
         _ExtentX        =   1552
         _ExtentY        =   547
         Appearance      =   0
         BackColor       =   -2147483643
         ForeColor       =   -2147483640
         Value           =   1
         Caption         =   "&Error"
      End
      Begin vbccr18.CheckBoxW chkLogInfo 
         Height          =   370
         Left            =   0
         TabIndex        =   7
         Top             =   0
         Width           =   880
         _ExtentX        =   1552
         _ExtentY        =   653
         Appearance      =   0
         BackColor       =   -2147483643
         ForeColor       =   -2147483640
         Value           =   1
         Caption         =   "&Info"
      End
   End
   Begin VBFLXGRD18.VBFlexGrid gridStats 
      Height          =   3610
      Left            =   4920
      TabIndex        =   11
      Top             =   450
      Width           =   2290
      _ExtentX        =   4039
      _ExtentY        =   6368
      FixedCols       =   0
      AllowBigSelection=   0   'False
      AllowSelection  =   0   'False
      SelectionMode   =   1
      ScrollBars      =   2
      ScrollTrack     =   -1  'True
      HighLight       =   2
      FocusRect       =   0
      ShowInfoTips    =   -1  'True
   End
   Begin vbccr18.CommandButtonW cmdCopy 
      Height          =   460
      Left            =   3960
      TabIndex        =   2
      Top             =   4200
      Width           =   1780
      _ExtentX        =   3140
      _ExtentY        =   811
      Enabled         =   0   'False
      Caption         =   "Copy to Clipboard"
   End
   Begin vbccr18.CommandButtonW cmdRun 
      Height          =   460
      Left            =   2040
      TabIndex        =   1
      Top             =   4200
      Width           =   1780
      _ExtentX        =   3140
      _ExtentY        =   811
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Enabled         =   0   'False
      Caption         =   "&Run"
      SplitButton     =   -1  'True
      SplitButtonNoSplit=   -1  'True
   End
   Begin vbccr18.CommandButtonW cmdSelectFiles 
      Height          =   460
      Left            =   120
      TabIndex        =   0
      Top             =   4200
      Width           =   1780
      _ExtentX        =   3140
      _ExtentY        =   811
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "&Select Files"
   End
   Begin VBFLXGRD18.VBFlexGrid gridFiles 
      Height          =   3610
      Left            =   240
      TabIndex        =   4
      Top             =   450
      Width           =   2290
      _ExtentX        =   4039
      _ExtentY        =   6368
      FixedCols       =   0
      AllowBigSelection=   0   'False
      AllowSelection  =   0   'False
      SelectionMode   =   1
      ScrollBars      =   2
      ScrollTrack     =   -1  'True
      HighLight       =   2
      FocusRect       =   0
      WordWrap        =   -1  'True
      ShowInfoTips    =   -1  'True
   End
   Begin vbccr18.TabStrip TabStrip1 
      Height          =   4090
      Left            =   60
      TabIndex        =   3
      Top             =   60
      Width           =   9610
      _ExtentX        =   16951
      _ExtentY        =   7214
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseTrack      =   -1  'True
      MultiRow        =   0   'False
      InitTabs        =   "frmMain.frx":0000
   End
   Begin VB.Menu mnuProcessors 
      Caption         =   "Processors"
      Begin VB.Menu mnuProcessorsProcessor 
         Caption         =   "Processor"
         Index           =   0
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private WithEvents mo_SourceInfos As CSourceInfos
Attribute mo_SourceInfos.VB_VarHelpID = -1
Private WithEvents mo_Log As CLog
Attribute mo_Log.VB_VarHelpID = -1
Private mo_Processors As RC6.cCollection
Attribute mo_Processors.VB_VarHelpID = -1
Private mo_Processor As ISourceProcessor
Attribute mo_Processor.VB_VarHelpID = -1

Private mo_Progress As frmProgress
Private mo_VbpInfos As CVbpInfos

Private m_MinLogLevel As e_LogLevel

Private m_StartedRunAt As Double
Private m_ProcessedFileCount As Long

Private Sub chkLogError_Click()
   FilterLogType "ERROR", chkLogError
End Sub

Private Sub chkLogImportant_Click()
   FilterLogType "IMPORTANT", chkLogImportant
End Sub

Private Sub chkLogInfo_Click()
   FilterLogType "INFO", chkLogInfo
End Sub

Private Sub chkLogWarn_Click()
   FilterLogType "WARNING", chkLogWarn
End Sub

Private Sub FilterLogType(ByVal p_Type As String, po_CheckBox As vbccr18.CheckBoxW)
   Dim ii As Long
   
   Me.gridLog.Redraw = False
   
   For ii = 1 To Me.gridLog.Rows - 1
      If Me.gridLog.TextMatrix(ii, 0) = p_Type Then
         Me.gridLog.RowHidden(ii) = Not (po_CheckBox.Value = Checked)
      End If
   Next ii
   
   UpdateLogTabCaption
   
   Me.gridLog.Redraw = True
End Sub

Private Sub cmdCopy_Click()
   Dim lo_Grid As VBFLXGRD18.VBFlexGrid
   Dim lo_Clip As RC6.cStringBuilder
   Dim ii As Long
   
   If Me.gridFiles.Visible Then
      Set lo_Grid = Me.gridFiles
   ElseIf Me.gridLog.Visible Then
      Set lo_Grid = Me.gridLog
   ElseIf Me.gridStats.Visible Then
      Set lo_Grid = Me.gridStats
   Else
      Debug.Assert False
   End If
   
   If lo_Grid Is Nothing Then
      MsgBox "No active grid!", vbExclamation + vbOKOnly, "Copy Error"
      
   Else
      With New_C.Clipboard
         .Clear
         
         If lo_Grid Is Me.gridFiles Then
            Set lo_Clip = New_C.StringBuilder
            
            For ii = 1 To Me.gridFiles.Rows - 1
               lo_Clip.Append Me.gridFiles.TextMatrix(ii, 1)
               If ii < Me.gridFiles.Rows - 1 Then
                  lo_Clip.AppendNL Me.gridFiles.TextMatrix(ii, 0)
               Else
                  lo_Clip.Append Me.gridFiles.TextMatrix(ii, 0)
               End If
            Next ii
            
            .SetText lo_Clip.ToString, CF_UNICODETEXT
            
         Else
            lo_Grid.AllowSelection = True
            
            lo_Grid.Row = lo_Grid.FixedRows
            lo_Grid.RowSel = lo_Grid.Rows - lo_Grid.FixedRows - 1
                     
            .SetText lo_Grid.Clip, CF_UNICODETEXT
            
            lo_Grid.AllowSelection = False
         End If
         
         MsgBox "Copied to clipboard.", vbOKOnly + vbInformation, "Copied"
      End With
   End If
End Sub

Private Sub UpdateProgressText()
   mo_Progress.ProgressPercent = m_ProcessedFileCount / mo_SourceInfos.Count * 100
   
   If mo_Processor Is Nothing Then
      mo_Progress.ProgressText = "Processing file " & m_ProcessedFileCount & " of " & mo_SourceInfos.Count
   Else
      mo_Progress.ProgressText = "Processing file " & m_ProcessedFileCount & " of " & mo_SourceInfos.Count & vbNewLine & ActiveISourceProcessor.ProcessedPhysicalLinesCount & " lines @ " & Format$(ActiveISourceProcessor.ProcessedPhysicalLinesCount / (New_C.HPTimer - m_StartedRunAt), "#,##0") & " lines/s"
   End If
End Sub

Private Function ActiveISourceProcessor() As ISourceProcessor
   Set ActiveISourceProcessor = mo_Processor
End Function

Private Sub cmdRun_Click()
   Me.PopupMenu Me.mnuProcessors
End Sub

Private Sub UpdateLogTabCaption()
   Me.TabStrip1.Tabs.Item(2).Caption = "Log (" & mo_Log.CountByTypes(Me.chkLogInfo.Value = Checked, Me.chkLogImportant.Value = Checked, Me.chkLogWarn.Value = Checked, Me.chkLogError.Value = Checked) & ")"
End Sub

Private Sub cmdSelectFiles_Click()
   Dim l_File As String ' File(s) returned from ShowOpenDialog call
   Dim la_Files() As String   ' Array of selected files as generated from split result of ShowOpenDialog call
   Dim lo_Files As RC6.cSortedDictionary ' Collection of selected files in ascending order
   
   Dim d As Double
   Dim ii As Long

   Screen.MousePointer = vbHourglass
   Me.cmdRun.Enabled = False

   l_File = New_C.FSO.ShowOpenDialog(OFN_ALLOWMULTISELECT + OFN_EXPLORER + OFN_FILEMUSTEXIST + OFN_HIDEREADONLY + OFN_LONGNAMES + OFN_PATHMUSTEXIST, _
                                     New_C.FSO.GetSpecialFolder(CSIDL_MYDOCUMENTS), _
                                     "Select a VB6 Project File or Group", _
                                     "", _
                                     "Visual Basic Project Files (*.vbp;*.vbg)|*.vbp;*.vbg", , _
                                     Me.hWnd)

   If Not stringsIsEmptyOrWhitespaceOnly(l_File) Then
      d = New_C.HPTimer

      Me.TabStrip1.SelectedItem = Me.TabStrip1.Tabs(1)

      Me.gridFiles.Visible = True
      Me.fraLog.Visible = False
      Me.gridStats.Visible = False
      
      Me.gridLog.Rows = 1
      Set mo_Log = New CLog

      Set mo_SourceInfos = New CSourceInfos
      logicallinesReset
      
      Set lo_Files = New_C.SortedDictionary(TextCompare, False)

      If InStr(1, l_File, "|") Then
         la_Files = Split(l_File, "|")
         For ii = 1 To UBound(la_Files)
            l_File = la_Files(0) & "\" & la_Files(ii)
            lo_Files.Add stringsConvertToSmartSortString(l_File), l_File
         Next ii
      Else
         lo_Files.Add stringsConvertToSmartSortString(l_File), l_File
      End If

      Set mo_VbpInfos = New CVbpInfos
      For ii = 0 To lo_Files.Count - 1
         mo_VbpInfos.AddVbpFilesFromFile lo_Files.ItemByIndex(ii)
      Next ii

      For ii = 0 To mo_VbpInfos.VbpInfoCount - 1
         mo_SourceInfos.AddFromVbpInfo mo_VbpInfos.VbpInfo(ii)
      Next ii
         
      RebuildSourceFileList
   
      mo_Log.LockLog
      Set Me.gridLog.FlexDataSource = mo_Log
      Me.TabStrip1.Tabs.Item(2).Caption = "Log (" & Me.gridLog.Rows - 2 & ")"
   
      If optShowVbpParseTiming Then
         MsgBox "Finished parsing " & mo_SourceInfos.Count & " source files." _
             & vbNewLine & "Warnings: " & mo_Log.WarningCount _
             & vbNewLine & "Errors: " & mo_Log.ErrorCount _
             & vbNewLine & vbNewLine & "Timing: " & Format$(New_C.HPTimer - d, "#,##0.0000") & " seconds.", _
             vbInformation + vbOKOnly, _
             "Parsing Complete."
      End If
   End If
      
   RefreshButtons

   Screen.MousePointer = vbDefault
End Sub

Private Sub RebuildSourceFileList()
   Dim ii As Long
   Dim lo_SourceInfo As CSourceInfo

   With Me.gridFiles
      If mo_SourceInfos.Count = 0 Then
         Me.gridFiles.Rows = 0
         
      Else
         .Rows = mo_SourceInfos.Count + 1
         .FixedRows = 1
      
         .Redraw = False
         
         .TextMatrix(0, 0) = "FILE"
         .TextMatrix(0, 1) = "FOLDER"
         
         For ii = 0 To mo_SourceInfos.Count - 1
            Set lo_SourceInfo = mo_SourceInfos.SourceInfo(ii)
            .TextMatrix(ii + 1, 0) = pathsGetFileFromPath(lo_SourceInfo.FilePath, True)
            .TextMatrix(ii + 1, 1) = New_C.FSO.GetPathNameFromFullPath(lo_SourceInfo.FilePath)
         Next ii
         
         .AutoSize 0, 1, FlexAutoSizeModeColWidth, FlexAutoSizeScopeAll, False
         
         .Redraw = True
         
         Me.TabStrip1.Tabs.Item(1).Caption = "Files (" & Me.gridFiles.Rows - 1 & ")"
      End If
   End With

   RefreshButtons
End Sub

Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
   Select Case KeyCode
   Case vbKeyC
      If Shift = vbCtrlMask Then
         ' Copy to clipboard
         Me.cmdCopy.PerformClick
      End If
   End Select
End Sub

Private Sub Form_Load()
   Dim ii As Long
   
   ' Setup the UI
   Me.chkLogInfo.Left = 0
   Me.chkLogInfo.Width = Me.chkLogImportant.Width  ' Set all Log option checkboxes to the widest checkbox width (IMPORTANT)
   With Me.chkLogImportant
      .Move Me.chkLogInfo.Left + Me.chkLogInfo.Width, Me.chkLogInfo.Top, Me.chkLogInfo.Width, Me.chkLogInfo.Height
   End With
   With Me.chkLogWarn
      .Move Me.chkLogImportant.Left + Me.chkLogImportant.Width, Me.chkLogImportant.Top, Me.chkLogInfo.Width, Me.chkLogInfo.Height
   End With
   With Me.chkLogError
      .Move Me.chkLogWarn.Left + Me.chkLogWarn.Width, Me.chkLogWarn.Top, Me.chkLogInfo.Width, Me.chkLogInfo.Height
   End With
   
   Me.gridFiles.Visible = True
   Me.fraLog.Visible = False
   Me.gridStats.Visible = False
   
   With Me.gridLog
      .Rows = 0
   End With
   
   With Me.gridFiles
      .Rows = 0
   End With
   
   m_MinLogLevel = loglevel_Information
   Set mo_SourceInfos = New CSourceInfos
   
   ' Setup processors
   Set mo_Processors = New_C.Collection(False)
   
   Dim lo_Processor As ISourceProcessor
   
   Set lo_Processor = New CProcExample
   mo_Processors.Add lo_Processor, lo_Processor.FriendlyName
   
   Set lo_Processor = New CProcExample2
   mo_Processors.Add lo_Processor, lo_Processor.FriendlyName
   
   Set lo_Processor = New CProcExample3
   mo_Processors.Add lo_Processor, lo_Processor.FriendlyName
   
   For ii = 0 To mo_Processors.Count - 1
      If ii > 0 Then
         Load mnuProcessorsProcessor(ii)
      End If
      mnuProcessorsProcessor(ii).Caption = mo_Processors.KeyByIndex(ii)
   Next
End Sub

Private Sub Form_Resize()
   On Error Resume Next
   
   With Me.TabStrip1
      .Move .Left, .Top, Me.ScaleWidth - .Left, Me.ScaleHeight - .Left * 3 - Me.cmdSelectFiles.Height
   End With
   
   With Me.gridFiles
      .Move Me.TabStrip1.ClientLeft + Me.TabStrip1.Left, Me.TabStrip1.ClientTop + Me.TabStrip1.Left, Me.TabStrip1.ClientWidth - Me.TabStrip1.Left * 2, Me.TabStrip1.ClientHeight - Me.TabStrip1.Left * 2
   End With
   
   With Me.fraLog
      .Move Me.gridFiles.Left, _
            Me.gridFiles.Top, _
            Me.gridFiles.Width, _
            Me.gridFiles.Height
   End With
   With Me.gridLog
      .Move 0, Me.chkLogInfo.Height, Me.fraLog.Width, Me.fraLog.Height - Me.chkLogInfo.Height
   End With
   
   
   With Me.gridStats
      .Move Me.gridFiles.Left, _
            Me.gridFiles.Top, _
            Me.gridFiles.Width, _
            Me.gridFiles.Height
   End With
   
   Me.cmdSelectFiles.Top = Me.ScaleHeight - Me.cmdSelectFiles.Height - Me.TabStrip1.Left
   Me.cmdRun.Top = Me.cmdSelectFiles.Top
   Me.cmdCopy.Top = Me.cmdSelectFiles.Top
   
   On Error GoTo 0
   Err.Clear
End Sub

Private Sub Form_Unload(Cancel As Integer)
   New_C.CleanupRichClientDll
End Sub

Private Sub gridFiles_KeyDown(KeyCode As Integer, Shift As Integer)
   Dim l_Index As Long
   
   If KeyCode = vbKeyDelete Then
      l_Index = Me.gridFiles.Row
      
      mo_SourceInfos.RemoveByIndex Me.gridFiles.Row - Me.gridFiles.FixedRows
      
      RebuildSourceFileList
      
      If Me.gridFiles.Rows > l_Index Then
         Me.gridFiles.Row = l_Index
         Me.gridFiles.CellEnsureVisible FlexVisibilityCompleteOnly
         
      ElseIf Me.gridFiles.Rows >= l_Index Then
         Me.gridFiles.Row = l_Index - 1
         Me.gridFiles.CellEnsureVisible FlexVisibilityCompleteOnly
         
      End If
   End If
End Sub

Private Sub mnuProcessorsProcessor_Click(Index As Integer)
   Dim ii As Long
   Dim lo_SourceInfo As CSourceInfo
   Dim lo_Confirm As frmConfirmRun
   Dim l_Cancel As Boolean
   
   Set mo_Processor = Nothing
   
   For ii = 0 To mo_Processors.Count - 1
      If mo_Processors.ItemByIndex(ii).FriendlyName = mnuProcessorsProcessor(Index).Caption Then
         Set mo_Processor = mo_Processors.ItemByIndex(ii)
         
         Exit For
      End If
   Next
   
   If Not mo_Processor Is Nothing Then
      Me.TabStrip1.SelectedItem = Me.TabStrip1.Tabs(1)
      
      If optRunConfirmationSeconds Then
         ' Ask the user to confirm that they want to perform potentially destructive operations on their source code.
         Set lo_Confirm = New frmConfirmRun
         lo_Confirm.Show vbModal, Me
         If lo_Confirm.UnloadMode <> vbOK Then Exit Sub
      End If
      
      m_StartedRunAt = New_C.HPTimer
      m_ProcessedFileCount = 0
      
      Set mo_Progress = New frmProgress
      mo_Progress.Show vbModeless, Me
      Me.Enabled = False
      
      Me.gridLog.Rows = 1
      Set mo_Log = New CLog
      
      LogMessage "Starting analysis of " & mo_SourceInfos.Count & " source files at " & Now & "..."
      
      Set ActiveISourceProcessor.Log = mo_Log
      
      For Each lo_SourceInfo In mo_SourceInfos
         m_ProcessedFileCount = m_ProcessedFileCount + 1
         
         UpdateProgressText
         
         ActiveISourceProcessor.ProcessSource lo_SourceInfo
      
         If mo_Progress.Cancelled Then Exit For
      Next lo_SourceInfo
      
      ActiveISourceProcessor.BeforeProcessingComplete l_Cancel
         
      If l_Cancel Then
         LogMessage "Analysis cancelled at " & Now & ". Total run time: " & Format$(New_C.HPTimer - m_StartedRunAt, "#,##0.00000") & " seconds."
      Else
         LogMessage "Finished analysis at " & Now & ". Total run time: " & Format$(New_C.HPTimer - m_StartedRunAt, "#,##0.00000") & " seconds."
      End If
      
      mo_Log.LockLog
      Set Me.gridLog.FlexDataSource = mo_Log
      Me.gridLog.FixedRows = 1
      
      Me.gridLog.ColWidth(0) = Me.gridLog.TextWidth(Me.gridLog.TextMatrix(1, 0)) * 3
      Me.gridLog.ColWidth(1) = Me.gridLog.Width - Me.gridLog.ColWidth(0)
      
      UpdateLogTabCaption
      
      Me.TabStrip1.Tabs(2).Selected = True
      
      Me.Enabled = True
      
      mo_Progress.Hide
      Unload mo_Progress
      Set mo_Progress = Nothing
   
      RefreshButtons
      
      If Not l_Cancel Then
         MsgBox "Finished processing source files." _
                & vbNewLine & "Warnings: " & mo_Log.WarningCount _
                & vbNewLine & "Errors: " & mo_Log.ErrorCount _
                & vbNewLine & vbNewLine & "Timing: " & formatSecondsToHumanReadable(New_C.HPTimer - m_StartedRunAt) & ".", _
                vbInformation + vbOKOnly, _
                "Processing Complete!"
      End If
      
      m_StartedRunAt = 0
   End If
End Sub

Private Sub mo_Log_MessageAdded(ByVal p_Message As String)
   If mo_Progress Is Nothing Then Exit Sub
   
   UpdateProgressText
   mo_Progress.InfoText = p_Message
   
   DoEvents
End Sub

Private Sub mo_Processor_CancelCheck(p_Cancel As Boolean)
   p_Cancel = mo_Progress.Cancelled
End Sub

Private Sub mo_SourceInfos_LogEvent(ByVal p_Message As String, ByVal p_LogLevel As e_LogLevel)
   LogMessage p_Message, p_LogLevel
End Sub

Private Sub LogMessage(ByVal p_Message As String, Optional ByVal p_LogLevel As e_LogLevel)
   If mo_Log Is Nothing Then Exit Sub
   If p_LogLevel < m_MinLogLevel Then Exit Sub
   
   If Not mo_Progress Is Nothing Then
      UpdateProgressText
      mo_Progress.InfoText = p_Message
   End If
   
   mo_Log.AddMessage p_Message, p_LogLevel
   
   DoEvents
End Sub

Private Sub RefreshButtons()
   Dim lo_Grid As VBFLXGRD18.VBFlexGrid
   
   If mo_SourceInfos Is Nothing Then
      Me.cmdRun.Enabled = False
   Else
      Me.cmdRun.Enabled = (mo_SourceInfos.Count > 0)
   End If
   
   If Me.gridFiles.Visible Then
      Set lo_Grid = Me.gridFiles
   ElseIf Me.gridLog.Visible Then
      Set lo_Grid = Me.gridLog
   Else
      Debug.Assert False
   End If

   If lo_Grid Is Nothing Then
      Me.cmdCopy.Enabled = False
   Else
      Me.cmdCopy.Enabled = (lo_Grid.Rows > lo_Grid.FixedRows)
   End If
End Sub

Private Sub TabStrip1_TabClick(ByVal TabItem As vbccr18.TbsTab)
   Dim l_TokenType As e_VbpTokenType
   
   Select Case TabItem.Index
   Case 1
      ' Files tab
      Me.gridFiles.Visible = True
      Me.fraLog.Visible = False
      Me.gridStats.Visible = False
      
   Case 2
      ' Log tab
      If mo_Log Is Nothing Then
         Me.TabStrip1.Tabs(1).Selected = True
      Else
         mo_Log.LockLog
         Set Me.gridLog.FlexDataSource = mo_Log
            
         With Me.gridLog
            .FixedRows = 1
            .RowSizingMode = FlexRowSizingModeIndividual
            .ColAlignment(0) = FlexAlignmentLeftTop
            .ColAlignment(1) = FlexAlignmentLeftTop
            .ColWidth(0) = Me.gridLog.TextWidth(Me.gridLog.TextMatrix(1, 0)) * 3
            .ColWidth(1) = Me.gridLog.Width - Me.gridLog.ColWidth(0)
            .AutoSize 1, Me.gridLog.Rows - 2, FlexAutoSizeModeRowHeight, FlexAutoSizeScopeAll
         End With
         
         Me.gridFiles.Visible = False
         Me.gridStats.Visible = False
         Me.fraLog.Visible = True
      End If
      
   Case 3
      ' Stats tab
      With Me.gridStats
         .Rows = 1
         .TextMatrix(0, 0) = "TYPE"
         .TextMatrix(0, 1) = "COUNT"
      End With
      
      If mo_VbpInfos Is Nothing Then
         ' No parsed files
      ElseIf mo_VbpInfos.VbpInfoCount = 0 Then
      
      Else
         mo_VbpInfos.BuildStats
         
         Me.gridStats.Redraw = False
         
         For l_TokenType = [_vbptokentype_First] To [_vbptokentype_Last]
            With Me.gridStats
               .Rows = .Rows + 1
            
               .TextMatrix(.Rows - 1, 0) = stringsVbpTokenTypeName(l_TokenType)
               .TextMatrix(.Rows - 1, 1) = statsCountByTokenType(l_TokenType)
            End With
         Next l_TokenType
         
         Dim l_PhysicalLineCount As Currency
         Dim lo_SourceInfo As CSourceInfo
         
         For Each lo_SourceInfo In mo_SourceInfos
            l_PhysicalLineCount = l_PhysicalLineCount + lo_SourceInfo.PhysicalLineCount
         Next lo_SourceInfo
            
         With Me.gridStats
            .Rows = .Rows + 1
            .TextMatrix(.Rows - 1, 0) = "Physical Lines"
            .TextMatrix(.Rows - 1, 1) = l_PhysicalLineCount
         End With
         
         Me.gridStats.AutoSize 0, 1, FlexAutoSizeModeColWidth, FlexAutoSizeScopeAll
         If Me.gridStats.Rows > 1 Then Me.gridStats.FixedRows = 1
         Me.gridStats.Redraw = True
         
      End If
         
      Me.gridFiles.Visible = False
      Me.fraLog.Visible = False
      Me.gridStats.Visible = True
   
   Case Else
      ' Huh? Should not be left unhandled.
      Debug.Assert False
      
   End Select
End Sub
