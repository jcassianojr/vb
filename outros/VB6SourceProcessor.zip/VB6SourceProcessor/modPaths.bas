Attribute VB_Name = "modPaths"
Option Explicit

Public Function pathsGetFileFromPath(ByVal p_FullPath As String, Optional ByVal p_IncludeExtension As Boolean = True) As String
   Dim l_Dot As Long
   
   pathsGetFileFromPath = New_c.FSO.GetFileNameFromFullPath(p_FullPath)
   If Not p_IncludeExtension Then
      l_Dot = InStrRev(pathsGetFileFromPath, ".")
      If l_Dot > 0 Then
         pathsGetFileFromPath = Left$(pathsGetFileFromPath, l_Dot - 1)
      End If
   End If
End Function

Public Function pathsConcatRelativePaths(ByVal p_BasePath As String, ByVal p_RelativePath As String) As String
   Dim l_RelCount As Long

   If Left$(p_RelativePath, 1) = "\" Then
      p_RelativePath = Mid$(p_RelativePath, 2)
   End If

   If Right$(p_BasePath, 1) = "\" Then
      p_BasePath = Left$(p_BasePath, Len(p_BasePath) - 1)
   End If

   Do While Left$(p_RelativePath, 3) = "..\"
      p_RelativePath = Mid$(p_RelativePath, 4)
      l_RelCount = l_RelCount + 1
   Loop

   Dim la_BasePath() As String

   la_BasePath = Split(p_BasePath, "\")
   ReDim Preserve la_BasePath(UBound(la_BasePath) - l_RelCount)
   
   pathsConcatRelativePaths = Join$(la_BasePath, "\") & "\" & p_RelativePath
End Function

