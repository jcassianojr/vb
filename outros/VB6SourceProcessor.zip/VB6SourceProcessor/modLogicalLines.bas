Attribute VB_Name = "modLogicalLines"
Option Explicit

Private mo_Cnn As RC6.cConnection
Private mo_InsertCmd As RC6.cCommand
Private mo_DeleteCmd As RC6.cCommand
Private mo_InsertMethodCmd As RC6.cCommand
Private mo_SelectCountCmd As RC6.cSelectCommand
Private mo_SelectContentCmd As RC6.cSelectCommand
Private mo_SelectLogicalLineInRangeByTypeCmd As RC6.cSelectCommand
Private mo_SelectContentRegexCmd As RC6.cSelectCommand
Private mo_SelectTypeInRangeCmd As RC6.cSelectCommand
Private mo_SelectMethodNameFromLogicalLineCmd As RC6.cSelectCommand

Private mo_Cache As RC6.cCollection   ' Cache of Logical Line recordsets

Private m_InEnum As Boolean
Private m_InType As Boolean

Private Enum e_MethodType
   methodtype_Sub
   methodtype_Function
   methodtype_PropertyGet
   methodtype_PropertyLet
   methodtype_PropertySet
End Enum

Private Enum e_MethodScope
   methodscope_Public
   methodscope_Private
   methodscope_Friend
End Enum

Private m_LastMethodScope As e_MethodScope
Private m_LastMethodIsStatic As Boolean
Private m_LastMethodType As e_MethodType
Private m_LastMethodName As String
Private m_LastObjPtr As Long

Sub logicallinesReset()
   Set mo_Cnn = Nothing
   Set mo_Cache = Nothing
   m_LastObjPtr = -1
End Sub

Private Sub InitIfNecessary()
   If mo_Cnn Is Nothing Then
      Set mo_Cnn = New_C.Connection(":memory:", DBCreateInMemory)
      mo_Cnn.Synchronous = SynchronousOff
      mo_Cnn.Execute "PRAGMA journal_mode=MEMORY"
      
      mo_Cnn.AddUserDefinedFunction New CDbFunctions
      
      mo_Cnn.Execute "CREATE TABLE logicallines (owner_objptr INTEGER, logicalline_num INTEGER, physicalline_start INTEGER, physicalline_end INTEGER, char_start INTEGER, char_end INTEGER, type INTEGER, content TEXT)"
      mo_Cnn.Execute "CREATE TABLE methods (logicalline_rowid INTEGER, scope INTEGER, is_static INTEGER, type INTEGER, name TEXT, CONSTRAINT fk_logicallines FOREIGN KEY(logicalline_rowid) REFERENCES logicallines(rowid) ON DELETE CASCADE)"
      
      ' Create INDEXes to improve performance
      mo_Cnn.Execute "CREATE UNIQUE INDEX uidx_owner_objptr_and_logicaline_num ON logicallines (owner_objptr, logicalline_num)"
      mo_Cnn.Execute "CREATE INDEX idx_logicaline_num ON logicallines (logicalline_num ASC)"
      mo_Cnn.Execute "CREATE INDEX idx_owner_objptr ON logicallines (owner_objptr ASC)"
      mo_Cnn.Execute "CREATE INDEX idx_type ON logicallines (type ASC)"
      mo_Cnn.Execute "CREATE INDEX idx_logicalline_num_and_owner_objptr ON logicallines (owner_objptr ASC, logicalline_num ASC)"
      mo_Cnn.Execute "CREATE INDEX idx_logicalline_num_and_owner_objptr_desc ON logicallines (owner_objptr ASC, logicalline_num DESC)"
      mo_Cnn.Execute "CREATE INDEX idx_logicalline_num_and_owner_objptr_and_type ON logicallines (owner_objptr ASC, type ASC, logicalline_num ASC)"
      mo_Cnn.Execute "CREATE INDEX idx_logicalline_num_and_owner_objptr_and_type_physical_char ON logicallines (owner_objptr ASC, type ASC, logicalline_num ASC, physicalline_start ASC, char_start ASC)"
      
      Set mo_InsertCmd = mo_Cnn.CreateCommand("INSERT INTO logicallines (owner_objptr, logicalline_num, physicalline_start, physicalline_end, char_start, char_end, type, content) VALUES (?,?,?,?,?,?,?,?)")
      Set mo_DeleteCmd = mo_Cnn.CreateCommand("DELETE FROM logicallines WHERE owner_objptr=?")
      Set mo_InsertMethodCmd = mo_Cnn.CreateCommand("INSERT INTO methods (logicalline_rowid, scope, is_static, type, name) VALUES ((SELECT rowid FROM logicallines WHERE owner_objptr=? AND logicalline_num=? LIMIT 1),?,?,?,?)")
      
      Set mo_SelectCountCmd = mo_Cnn.CreateSelectCommand("SELECT COUNT(1) FROM logicallines WHERE type & ? AND CASE WHEN ?=0 THEN owner_objptr<>? ELSE owner_objptr=? END")
      Set mo_SelectContentCmd = mo_Cnn.CreateSelectCommand("SELECT content, type FROM logicallines WHERE owner_objptr=? ORDER BY rowid ASC")
      Set mo_SelectLogicalLineInRangeByTypeCmd = mo_Cnn.CreateSelectCommand("SELECT logicalline_num FROM logicallines WHERE (owner_objptr=?) AND (type & ?) AND (logicalline_num>=?) AND (logicalline_num<=?) ORDER BY physicalline_start ASC, char_start ASC LIMIT 1")
      
      Set mo_SelectContentRegexCmd = mo_Cnn.CreateSelectCommand("SELECT COUNT(1) FROM logicallines " & _
                                    "WHERE owner_objptr=?" & _
                                    " AND type & ?" & _
                                    " AND logicalline_num>=?" & _
                                    " AND logicalline_num<=?" & _
                                    " AND CONTENTREGEX(content, ?, ?) LIMIT 1")
      
      Set mo_SelectTypeInRangeCmd = mo_Cnn.CreateSelectCommand("SELECT COUNT(1) FROM logicallines " & _
                                    "WHERE owner_objptr=?" & _
                                    " AND type & ?" & _
                                    " AND logicalline_num>=?" & _
                                    " AND logicalline_num<=? LIMIT 1")
                                    
      Set mo_SelectMethodNameFromLogicalLineCmd = mo_Cnn.CreateSelectCommand("SELECT name FROM methods " & _
                                                                              "WHERE logicalline_rowid=" & _
                                                                              "(SELECT rowid FROM logicallines WHERE owner_objptr=? AND type=? AND logicalline_num<=? ORDER BY logicalline_num DESC LIMIT 1)")
      
      
      Set mo_Cache = New_C.Collection
   End If
End Sub

Public Sub logicallinesSaveInfo(po_ParentObject As Object, _
                                ByVal p_ZeroBasedPhysicalLineIndexStart As Long, _
                                ByVal p_ZeroBasedPhysicalLineIndexEnd As Long, _
                                ByVal p_ZeroBasedStartCharIndex As Long, _
                                ByVal p_ZeroBasedEndCharIndex As Long, _
                                pa_PhysicalLines() As String, _
                                Optional ByVal p_LogicalLineType As e_LogicalLineType = [_logicallinetype_AutoDetect])
   
   Static s_LineCount As Long
   
   Dim l_LogicalLineContent As String
   Dim ii As Long
   Dim l_Line As String
   Dim l_CacheKey As String
   
   On Error GoTo ErrorHandler
   
   InitIfNecessary
   
   l_CacheKey = CacheKey(po_ParentObject)
   If mo_Cache.Exists(l_CacheKey) Then
      mo_Cache.Remove l_CacheKey
   End If
   
   If ObjPtr(po_ParentObject) <> m_LastObjPtr Then
      m_LastObjPtr = ObjPtr(po_ParentObject)
      s_LineCount = 1
   Else
      s_LineCount = s_LineCount + 1
   End If
   
   ' Get Logical Line Content from passed Physical Line info
   If p_ZeroBasedPhysicalLineIndexStart = p_ZeroBasedPhysicalLineIndexEnd Then
      ' Singleline (or portion thereof)
      l_LogicalLineContent = Mid$(pa_PhysicalLines(p_ZeroBasedPhysicalLineIndexStart), p_ZeroBasedStartCharIndex + 1, p_ZeroBasedEndCharIndex - p_ZeroBasedStartCharIndex + 1)
               
   Else
      ' Multiline - build content without line continuation characters.
      For ii = p_ZeroBasedPhysicalLineIndexStart To p_ZeroBasedPhysicalLineIndexEnd
         l_Line = pa_PhysicalLines(ii)
         
         If ii = p_ZeroBasedPhysicalLineIndexStart Then
            ' First line of continued lines - get line text except trailing underscore
            l_LogicalLineContent = LTrim$(Mid$(l_Line, p_ZeroBasedStartCharIndex + 1, Len(RTrim$(l_Line)) - 1))
         
         ElseIf ii = p_ZeroBasedPhysicalLineIndexEnd Then
            ' Last line of continued lines - append line text up to the end char index
            l_LogicalLineContent = l_LogicalLineContent & LTrim$(Left$(l_Line, p_ZeroBasedEndCharIndex + 1))
         
         Else
            ' Internal line of set of continued lines - append line text except trailing underscore
            l_LogicalLineContent = l_LogicalLineContent & Left$(Trim$(l_Line), Len(Trim$(l_Line)) - 1)
         
         End If
      Next ii
   End If
      
   If p_LogicalLineType = [_logicallinetype_AutoDetect] Then
      ' Autodetect logical line type based on content
      p_LogicalLineType = LogicalLineTypeFromContent(l_LogicalLineContent)
      
      ' Confirm that the returned logical line type is correct/legal
      ' For example, you can't start a new enum when one is already open, or when a type block is open
      ' We also must change logicallinetype_Statement to logicallinetype_EnumMember when an enum block is open
      ' or to logicallinetype_TypeMember when a type block is open.
      
      Select Case p_LogicalLineType
      Case logicallinetype_EnumStart
         If m_InEnum Then
            ' Code error! Can't be start a new Enum when Enum block is already open!
            Err.Raise vbObjectError, , "Code Error! Can't start an Enum block when one is already open!"
         End If
         
         If m_InType Then
            ' Code error! Can't start a new Enum when Type block is open!
            Err.Raise vbObjectError, , "Code Error! Can't start an Enum block when a Type block is open!"
         End If
         
         m_InEnum = True
         
      Case logicallinetype_EnumEnd
         If Not m_InEnum Then
            ' Code error! Can't close an Enum block when it isn't already open!
            Err.Raise vbObjectError, , "Code Error! Can't close an Enum block when it isn't open!"
         End If
         
         m_InEnum = False
         
      Case logicallinetype_TypeStart
         If m_InType Then
            ' Code error! Can't be start a new Type when Type block is already open!
            Err.Raise vbObjectError, , "Code Error! Can't start a Type block when one is already open!"
         End If
         
         If m_InEnum Then
            ' Code error! Can't start a new Type when Enum block is open!
            Err.Raise vbObjectError, , "Code Error! Can't start a Type block when an Enum block is open!"
         End If
         
         m_InType = True
         
      Case logicallinetype_TypeEnd
         If Not m_InType Then
            ' Code error! Can't close a Type block when it isn't already open!
            Err.Raise vbObjectError, , "Code Error! Can't close a Type block when it isn't open!"
         End If
         
         m_InType = False
         
      Case logicallinetype_Statement
         ' Statements are the "default" line type, but if we are in
         ' an Enum or Type block we should change the type accordingly
         If m_InEnum Then
            p_LogicalLineType = logicallinetype_EnumMember
         ElseIf m_InType Then
            p_LogicalLineType = logicallinetype_TypeMember
         End If
      End Select
      
   End If
   
   If envDebugMode Then
      Debug.Print "Saving Logical Line Info: " & stringsLogicalLineTypeName(p_LogicalLineType) & ", " & _
                                                 p_ZeroBasedPhysicalLineIndexStart & ", " & _
                                                 p_ZeroBasedPhysicalLineIndexEnd & ", " & _
                                                 p_ZeroBasedStartCharIndex & ", " & _
                                                 p_ZeroBasedEndCharIndex
   End If
   
   mo_Cnn.BeginTrans
   
   With mo_InsertCmd
      .SetInt32 1, ObjPtr(po_ParentObject)
      .SetInt32 2, s_LineCount
      .SetInt32 3, p_ZeroBasedPhysicalLineIndexStart + 1
      .SetInt32 4, p_ZeroBasedPhysicalLineIndexEnd + 1
      .SetInt32 5, p_ZeroBasedStartCharIndex + 1
      .SetInt32 6, p_ZeroBasedEndCharIndex + 1
      .SetInt32 7, p_LogicalLineType
      .SetText 8, l_LogicalLineContent
      
      If Not .Execute Then
         ' Could not insert logical line record info
         Debug.Assert False
         Err.Raise vbObjectError, , "Could not insert logical line information! Last DB Error: " & mo_InsertCmd.ActiveConnection.LastDBError
      End If
   
      .SetAllParamsNull
   End With

   If p_LogicalLineType = logicallinetype_MethodStart Then
      With mo_InsertMethodCmd
         .SetInt32 1, ObjPtr(po_ParentObject)
         .SetInt32 2, s_LineCount
         .SetInt32 3, m_LastMethodType
         .SetInt32 4, m_LastMethodScope
         .SetInt32 5, Abs(m_LastMethodIsStatic)
         .SetText 6, m_LastMethodName
         
         If Not .Execute Then
            Debug.Assert False
            Err.Raise vbObjectError, , "Could not insert method information! Last DB Error: " & mo_InsertMethodCmd.ActiveConnection.LastDBError
         End If
      End With
   End If

   mo_Cnn.CommitTrans
   
   Exit Sub

ErrorHandler:
   Debug.Assert False
   Resume Next
   
   If Not mo_Cnn Is Nothing Then
      If mo_Cnn.TransactionStackCounter > 0 Then
         mo_Cnn.RollbackTrans
      End If
   End If
   
   Err.Raise Err.Number, Err.Source, Err.Description, Err.HelpFile, Err.HelpContext
End Sub

Private Function LogicalLineTypeFromContent(ByVal p_Content As String) As e_LogicalLineType
   p_Content = LCase$(stringsFlattenWhitespace(p_Content, stringtt_Both))
   With RegexMatch(p_Content, "^([0-9]+\s*)")
      If .FoundMatch Then
         ' Strip line #?
         p_Content = Mid$(p_Content, Len(.SubMatches(1)) + 1)
      End If
   End With
   
   ' Perform simple detections first, then more complicated (regex) detections
   ' if simple detections fail
   If p_Content = vbNullString Then
      ' Empty line
      LogicalLineTypeFromContent = logicallinetype_Empty
   
   Else
      Select Case Left$(p_Content, 1)
      Case "#"
         ' Conditional Compilation directive detected (line starts with #)
         LogicalLineTypeFromContent = logicallinetype_ConditionalCompilation
         
      Case "'"
         ' Comment line detected (line starts with apostrophe)
         LogicalLineTypeFromContent = logicallinetype_Comment
         
      Case Else
         If Left$(p_Content, 7) = "option " Then
            ' Option directive detected (line starts with "OPTION ")
            LogicalLineTypeFromContent = logicallinetype_Option
            
         ElseIf Left$(p_Content, Len("end enum")) = "end enum" Then
            ' End Enum line detected
            If Not m_InEnum Then Debug.Assert False
            
            LogicalLineTypeFromContent = logicallinetype_EnumEnd
            
         ElseIf Left$(p_Content, Len("end type")) = "end type" Then
            ' End Type line detected
            LogicalLineTypeFromContent = logicallinetype_TypeEnd
         
         ElseIf Left$(p_Content, Len("type as ")) = "type as " Then
            If m_InType Then
               LogicalLineTypeFromContent = logicallinetype_TypeMember
            Else
               LogicalLineTypeFromContent = logicallinetype_VariableDeclaration
            End If
            
         ElseIf Left$(p_Content, Len("enum as ")) = "enum as " Then
            If m_InType Then
               LogicalLineTypeFromContent = logicallinetype_TypeMember
            Else
               LogicalLineTypeFromContent = logicallinetype_VariableDeclaration
            End If
            
         Else
            ' These are more complex detections using Regexes
            If RegexMatch(p_Content, "^Attribute\s").FoundMatch Then
               ' Hidden Attribute line detected (line starts with "Attribute ")
               LogicalLineTypeFromContent = logicallinetype_Attribute
               
            ElseIf RegexMatch(p_Content, "^(Public\s+|\s*)(Event\s+)").FoundMatch Then
               ' Event declaration line detected (e.g. Public/<EmptyString> Event)
               LogicalLineTypeFromContent = logicallinetype_EventDeclaration
            
            Else
               With RegexMatch(p_Content, "^(Private\s+|Public\s+|Friend\s+|\s*)(Static\s+|\s*)(Sub\s+|Function\s+|Property\s+(Get\s+|Let\s+|Set\s+))([A-Z]+[^\(]*)")
               If .FoundMatch Then
                  ' Method start line detected (e.g. Public/Private/Friend/<EmptyString> (Static) Sub/Function/Property)
                  LogicalLineTypeFromContent = logicallinetype_MethodStart
               
                  Select Case Trim$(.SubMatches(1))
                  Case "", "public"
                     ' Public method
                     m_LastMethodScope = methodscope_Public
                  Case "private"
                     ' Private method
                     m_LastMethodScope = methodscope_Private
                  Case "friend"
                     ' Friend method
                     m_LastMethodScope = methodscope_Friend
                  Case Else
                     ' HUH?
                     Debug.Assert False
                  End Select
                  
                  Select Case Trim$(.SubMatches(2))
                  Case "static"
                     ' Static method
                     m_LastMethodIsStatic = True
                  Case ""
                     ' Non-static method
                     m_LastMethodIsStatic = False
                  Case Else
                     ' HUH?
                     Debug.Assert False
                  End Select
                  
                  Select Case stringsFlattenWhitespace(.SubMatches(3), stringtt_Both)
                  Case "sub"
                     ' Sub
                     m_LastMethodType = e_MethodType.methodtype_Sub
                  Case "function"
                     ' Function
                     m_LastMethodType = e_MethodType.methodtype_Function
                  Case "property get"
                     ' Property Get
                     m_LastMethodType = e_MethodType.methodtype_PropertyGet
                  Case "property let"
                     ' Property Let
                     m_LastMethodType = e_MethodType.methodtype_PropertyLet
                  Case "property set"
                     ' Property Set
                     m_LastMethodType = e_MethodType.methodtype_PropertySet
                  Case Else
                     ' HUH?
                     Debug.Assert False
                  End Select
               
                  m_LastMethodName = Trim$(.SubMatches(5))
               
               ElseIf RegexMatch(p_Content, "^End\s+(Sub|Property|Function)$").FoundMatch Then
                  ' Method end line detected (e.g. End Sub/Function/Property)
                  LogicalLineTypeFromContent = logicallinetype_MethodEnd
                  
               ElseIf RegexMatch(p_Content, "^(Private\s+|Public\s+|\s*)(Declare\s+)").FoundMatch Then
                  ' API declare line detected (e.g. line starts with Private/Public/<EmptyString> Declare)
                  LogicalLineTypeFromContent = logicallinetype_ApiDeclaration
                  
               ElseIf RegexMatch(p_Content, "^(Private\s+|Public\s+|\s*)(Enum\s+)").FoundMatch Then
                  ' Enum declaration line detected (line starts with Private/Public/<EmptyString> Enum ")
                  LogicalLineTypeFromContent = logicallinetype_EnumStart
               
               ElseIf RegexMatch(p_Content, "^(Private\s+|Public\s+|\s*)(Type\s+)(.*)").FoundMatch Then
                  ' Type declaration line detected (line starts with Private/Public/<EmptyString> Type ")
                  LogicalLineTypeFromContent = logicallinetype_TypeStart
                  
               ElseIf RegexMatch(p_Content, "^(Private\s+|Public\s+|\s*)(Const\s+)").FoundMatch Then
                  ' Constact declaration line detected (e.g. Private Const mc_MyConst As Long = 1)
                  LogicalLineTypeFromContent = logicallinetype_ConstantDeclaration
                  
               ElseIf RegexMatch(p_Content, "^(Private\s+|Dim\s+|Static\s+)").FoundMatch Then
                  ' Variable declaration line detected (e.g. Private l_MyVar As Long)
                  LogicalLineTypeFromContent = logicallinetype_VariableDeclaration
                  
               ElseIf RegexMatch(p_Content, "^\s*(?:[0-9]*)\s*On\s+Error\s+Resume\s+Next\s*$").FoundMatch Then
                  ' On Error Resume Next
                  LogicalLineTypeFromContent = logicallinetype_OnErrorGotoResumeNext
                  
               ElseIf RegexMatch(p_Content, "^\s*(?:[0-9]*)\s*Resume\s*").FoundMatch Then
                  ' Resume from errorhandler
                  LogicalLineTypeFromContent = logicallinetype_Resume
                  
               Else
                  With RegexMatch(p_Content, "^\s*(?:[0-9]*)\s*On\s+Error\s+Goto\s+(.+)")
                     If .FoundMatch Then
                        Select Case .SubMatches(1)
                        Case "0"
                           ' On Error Goto 0
                           LogicalLineTypeFromContent = logicallinetype_OnErrorGotoZero
                        
                        Case "-1"
                           ' On Error Goto -1
                           LogicalLineTypeFromContent = logicallinetype_OnErrorGotoNegativeOne
                        
                        Case Else
                           ' On Error Goto <Label/LineNumber>
                           LogicalLineTypeFromContent = logicallinetype_OnErrorGotoLabel
                        
                        End Select
                     Else
                        ' Default is just a regular statement line
                        LogicalLineTypeFromContent = logicallinetype_Statement
                     End If
                  End With
               End If
               End With
            End If
         End If
      End Select
   End If
End Function

Public Sub logicallinesDeleteByParentObject(po_ParentObject As Object)
   InitIfNecessary
   
   If mo_DeleteCmd Is Nothing Then Exit Sub
   
   With mo_DeleteCmd
      .SetInt32 1, ObjPtr(po_ParentObject)
      
      If Not .Execute Then
         ' Should have succeeded?
         Debug.Assert False
      End If
      
      .SetAllParamsNull ' Cleanup
   End With
   
   If mo_Cache.Exists(CacheKey(po_ParentObject)) Then mo_Cache.Remove CacheKey(po_ParentObject)
End Sub

Public Function logicallinesCount(po_ParentObject As Object, Optional ByVal p_LogicalLineTypes As e_LogicalLineType = logicallinetype_MultiAll) As Long
   ' Pass a parent object to limit logical lines count to that parent's logical lines
   ' Pass nothing to return the total # of logical lines
   
   If mo_SelectCountCmd Is Nothing Then Err.Raise 5, , "Not initialized."

   With mo_SelectCountCmd
      .SetInt32 1, p_LogicalLineTypes
      .SetInt32 2, ObjPtr(po_ParentObject)
      .SetInt32 3, ObjPtr(po_ParentObject)
      .SetInt32 4, ObjPtr(po_ParentObject)
      
      logicallinesCount = .Execute.Fields(0).Value
   End With
End Function

Public Function logicallinesContentByParentObject(po_ParentObject As Object, ByVal p_OneBasedLineNumber As Long) As String
   Dim lo_Rs As RC6.cRecordset
   Dim l_CacheKey As String
   
   If mo_SelectContentCmd Is Nothing Then Err.Raise 5, , "Not initialized."
   
   l_CacheKey = CacheKey(po_ParentObject)
   If mo_Cache.Exists(l_CacheKey) Then
      Set lo_Rs = mo_Cache(l_CacheKey)
   
   Else
      With mo_SelectContentCmd
         .SetInt32 1, ObjPtr(po_ParentObject)
         
         Set lo_Rs = .Execute
      End With
   
      mo_Cache.Add lo_Rs, l_CacheKey
   End If
      
   logicallinesContentByParentObject = lo_Rs.ValueMatrix(p_OneBasedLineNumber - 1, 0)
End Function

Public Function logicallinesType(po_ParentObject As Object, ByVal p_OneBasedLineNumber As Long) As e_LogicalLineType
   Dim lo_Rs As RC6.cRecordset
   Dim l_CacheKey As String
   
   If mo_SelectContentCmd Is Nothing Then Err.Raise 5, , "Not initialized."
   
   l_CacheKey = CacheKey(po_ParentObject)
   If mo_Cache.Exists(l_CacheKey) Then
      Set lo_Rs = mo_Cache(l_CacheKey)
      
   Else
      With mo_SelectContentCmd
         .SetInt32 1, ObjPtr(po_ParentObject)
                  
         Set lo_Rs = .Execute
      End With
   
      mo_Cache.Add lo_Rs, l_CacheKey
   End If
      
   logicallinesType = lo_Rs.ValueMatrix(p_OneBasedLineNumber - 1, 1)
End Function

Public Function logicallinesFindNextByType(po_ParentObject As Object, ByVal p_LogicalLineType As e_LogicalLineType, ByVal p_StartAtOneBasedLineNumber As Long, ByVal p_EndAtOneBasedLineNumber As Long) As Long
   Dim lo_Rs As RC6.cRecordset
   
   If mo_SelectLogicalLineInRangeByTypeCmd Is Nothing Then Err.Raise 5, , "Not initialized."
   
   With mo_SelectLogicalLineInRangeByTypeCmd
      .SetInt32 1, ObjPtr(po_ParentObject)
      .SetInt32 2, p_LogicalLineType
      .SetInt32 3, p_StartAtOneBasedLineNumber
      .SetInt32 4, p_EndAtOneBasedLineNumber
      
      Set lo_Rs = .Execute
   End With
      
   If lo_Rs.RecordCount > 0 Then
      logicallinesFindNextByType = lo_Rs(0)
   End If
End Function

Public Function logicallinesRegexMatch(po_ParentObject As Object, ByVal p_Regex As String, Optional ByVal p_CaseSensitive As Boolean = False, Optional ByVal p_StartAtOneBasedLineNumber As Long = 1, Optional ByVal p_StopAfterOneBasedLineNumber As Long = &H7FFFFFFF, Optional ByVal p_SearchLineTypes As e_LogicalLineType = logicallinetype_MultiVisible) As Boolean
   ' Return TRUE if regex matches any logical line content within a range of logical lines
   
   InitIfNecessary
   
   With mo_SelectContentRegexCmd
      .SetInt32 1, ObjPtr(po_ParentObject)
      .SetInt32 2, p_SearchLineTypes
      .SetInt32 3, p_StartAtOneBasedLineNumber
      .SetInt32 4, p_StopAfterOneBasedLineNumber
      .SetText 5, p_Regex
      .SetInt32 6, CLng(IIf(p_CaseSensitive, vbBinaryCompare, vbTextCompare))
      
      logicallinesRegexMatch = (mo_SelectContentRegexCmd.Execute.Fields(0).Value > 0)
   End With
End Function

Public Function logicallinesTypeInRange(po_ParentObject As Object, ByVal p_LogicalLineTypes As e_LogicalLineType, ByVal p_StartAtOneBasedLineNumber As Long, ByVal p_StopAfterOneBasedLineNumber As Long) As Boolean
   ' Return TRUE if the passed logical line type is found within a range of logical lines
   
   InitIfNecessary
   
   With mo_SelectTypeInRangeCmd
      .SetInt32 1, ObjPtr(po_ParentObject)
      .SetInt32 2, p_LogicalLineTypes
      .SetInt32 3, p_StartAtOneBasedLineNumber
      .SetInt32 4, p_StopAfterOneBasedLineNumber
      
      logicallinesTypeInRange = (.Execute.Fields(0).Value > 0)
   End With
End Function

Public Function logicallinesMethodNameFromLogicalLine(po_ParentObject As Object, ByVal p_OneBasedLogicalLineNumber As Long) As String
   InitIfNecessary
   
   With mo_SelectMethodNameFromLogicalLineCmd
      .SetInt32 1, ObjPtr(po_ParentObject)
      .SetInt32 2, e_LogicalLineType.logicallinetype_MethodStart
      .SetInt32 3, p_OneBasedLogicalLineNumber
      
      logicallinesMethodNameFromLogicalLine = .Execute.Fields(0).Value
   End With
End Function

Private Function CacheKey(po_ParentObject As Object) As String
   CacheKey = "POBJ_" & ObjPtr(po_ParentObject)
End Function

