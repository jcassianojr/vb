VERSION 5.00
Object = "{7020C36F-09FC-41FE-B822-CDE6FBB321EB}#1.2#0"; "vbccr18.OCX"
Begin VB.Form frmProgress 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Working..."
   ClientHeight    =   2910
   ClientLeft      =   30
   ClientTop       =   370
   ClientWidth     =   4870
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2910
   ScaleWidth      =   4870
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin vbccr18.CommandButtonW btnCancel 
      Cancel          =   -1  'True
      Default         =   -1  'True
      Height          =   400
      Left            =   1620
      TabIndex        =   1
      Top             =   2400
      Width           =   1450
      _ExtentX        =   2558
      _ExtentY        =   706
      Object.Default         =   -1  'True
      Caption         =   "&Cancel"
   End
   Begin vbccr18.ProgressBar barProgress 
      Height          =   520
      Left            =   360
      Top             =   300
      Width           =   4150
      _ExtentX        =   7320
      _ExtentY        =   917
      Step            =   10
      Scrolling       =   2
   End
   Begin vbccr18.LabelW lblInfo 
      Height          =   730
      Left            =   150
      TabIndex        =   2
      Top             =   1470
      Width           =   4480
      _ExtentX        =   7902
      _ExtentY        =   1288
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   7
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
      WordWrap        =   -1  'True
      EllipsisFormat  =   3
      VerticalAlignment=   1
   End
   Begin vbccr18.LabelW lblProgress 
      Height          =   460
      Left            =   210
      TabIndex        =   0
      Top             =   870
      Width           =   4480
      _ExtentX        =   7902
      _ExtentY        =   811
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
      Caption         =   "Working..."
      WordWrap        =   -1  'True
      EllipsisFormat  =   3
      VerticalAlignment=   1
   End
End
Attribute VB_Name = "frmProgress"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Cancelled As Boolean

Private m_StartedAt As Double

Public Property Let ProgressPercent(ByVal p_Percent As Long)
   If Me.Cancelled Then Exit Property
   
   Me.barProgress.Value = p_Percent
End Property

Public Property Let ProgressText(ByVal p_Text As String)
   If Me.Cancelled Then Exit Property
   
   RefreshTiming
   Me.lblProgress.Caption = p_Text
   Me.Refresh
End Property

Public Property Let InfoText(ByVal p_Text As String)
   If Me.Cancelled Then Exit Property
   
   RefreshTiming
   Me.lblInfo.Caption = p_Text
   Me.Refresh
End Property

Private Sub RefreshTiming()
   Static s_LastUpdateAt As Double
   
   Dim l_Seconds As Double
   
   If Me.Cancelled Then Exit Sub ' Shortcircuit on user cancel
   
   If New_C.HPTimer - s_LastUpdateAt >= 1 Then
      ' Only update at >=1 second interval to try to avoid annoying quick changes of seconds in sub-second time
      ' For something smoother a thread could be used, but this is "good enough" for my purposes.
      l_Seconds = New_C.HPTimer - m_StartedAt
      
      If l_Seconds >= 1 Then
         Me.Caption = "Working..." & formatSecondsToHumanReadable(l_Seconds)
      End If
      
      s_LastUpdateAt = New_C.HPTimer
   End If
End Sub

Private Sub btnCancel_Click()
   Me.Cancelled = True
   
   Me.barProgress.State = PrbStatePaused
   Me.lblInfo.Caption = vbNullString
   Me.lblProgress.Caption = "Cancelling..."
   Me.Caption = "Cancelling..."
   With Me.btnCancel
      .Caption = "Cancelling..."
      .Enabled = False
   End With
   Me.Refresh
End Sub

Private Sub Form_Load()
   With Me.btnCancel
      .Move Me.ScaleWidth / 2 - .Width / 2
   End With
   With Me.lblInfo
      .Move Me.ScaleWidth / 2 - .Width / 2
   End With
   With Me.lblProgress
      .Move Me.ScaleWidth / 2 - .Width / 2
   End With
   With Me.barProgress
      .Move Me.ScaleWidth / 2 - .Width / 2
   End With
   
   With Me.barProgress
      .Step = 1
      .Min = 0
      .Max = 100
      .VisualStyles = True
      .State = PrbStateNormal
      .ShowInTaskbar = True
   End With
   
   m_StartedAt = New_C.HPTimer
End Sub

