Attribute VB_Name = "modStrings"
Option Explicit

Private Const FADF_AUTO      As Integer = &H1   'An array that is allocated on the stack.
Private Const FADF_FIXEDSIZE As Integer = &H10  'An array that may not be resized or reallocated.

Private Type SAFEARRAY1D    'Represents a safe array. (One Dimensional)
    cDims      As Integer   'The count of dimensions.
    fFeatures  As Integer   'Flags used by the SafeArray.
    cbElements As Long      'The size of an array element.
    cLocks     As Long      'The number of times the array has been locked without a corresponding unlock.
    pvData     As Long      'Pointer to the data.
    cElements  As Long      'The number of elements in the dimension.
    lLbound    As Long      'The lower bound of the dimension.
End Type                    'https://msdn.microsoft.com/en-us/library/ms221482(v=vs.85).aspx

Private Declare Function VarPtrArray Lib "msvbvm60.dll" Alias "VarPtr" (ByRef ArrayVar() As Any) As Long
Private Declare Sub PutMem4 Lib "msvbvm60.dll" (ByVal addr As Long, ByVal NewVal As Long)

Private Const mc_PadLength As Long = 32      ' If you expect to have numbers within your strings,
Private ma_Zeros(1 To mc_PadLength - 1) As String      ' Precomputed space padding for ConvertToSmartSortString

Public Function stringsConvertToSmartSortString(ByVal p_String As String, Optional ByVal p_FlattenWhitespace As Boolean = True, Optional ByVal p_TrimType As e_StringTrimType = stringtt_Both) As String
   '---------------------------------------------------------------------------------------
   ' Procedure  : ConvertToSmartSortString
   ' Author     : Jason Peter Brown
   ' Date       : Apr 18, 2011 @ 07:50
   ' Purpose    : To convert a string into a format that will allow for "smart" sorting
   '              When sorting lists of alpha-numeric strings
   '              See Notes for more information.
   ' Parameters : p_String - The string to make "smart-sort" ready
   '              p_Trim - True = trim leading and trailing spaces from the result
   '                       False= leave leading and trailing spaces alone
   '              p_FlattenWhitespace - True = Convert Tab, CR and LF characters to spaces,
   '                                           then flatten runs of 2 or more space characters
   '                                           into a single space character.
   '                                           convert Tab, Cr and Lf characters to
   '                                    False = Leave whitespace alone
   ' Returns    : A "smart-sort" ready version of the passed string
   ' Notes      : "Smart sorting" string have runs of numeric characters padded with
   '              leading zeros. For example, imaging the following items in a list:
   '              Doc 1 REV 1
   '              Doc 1 rev 2
   '              doc 1 rev 10
   '              Doc 10 rev 2
   '
   '              Here's how the resultant lists would appear when sorted with standard
   '              Text string comparisons, Binary string comparisons
   '              and SmartSort string comparisons:
   '
   '              Case-insensitive string compare
   '               Doc 1 rev 1
   '               doc 1 rev 10
   '               Doc 1 REV 2
   '               Doc 10 rev 2
   '
   '              Binary string compare
   '               Doc 1 REV 2
   '               Doc 1 rev 1
   '               Doc 10 rev 2
   '               doc 1 rev 10
   '
   '              Smart-sort comparison
   '               Doc 1 rev 1
   '               Doc 1 REV 2
   '               doc 1 rev 10
   '               Doc 10 rev 2
   '
   '              IMPORTANT: The returned strings should be used as Keys for
   '                         Key/Value pair sorting, not displayed to the user
   '                        As they will appear strange to the user.
   '                         For example, "Doc 1" becomes "Doc 00000000000000000000000000000001"
   '                         So you sort on the return values from this function,
   '                         But display the originally passed values to the user.
   '---------------------------------------------------------------------------------------

   ' then you should increase this value to cover the max. expected length

   Static s_Initialized As Boolean

   Dim l_Len As Long      ' Length of passed string
   Dim i As Long
   Dim l_NextIndex As Long

   If LenB(p_String) = 0 Then
      ' Nothing to convert, so short-circuit
      Exit Function
   End If

   If Not s_Initialized Then
      For i = 1 To UBound(ma_Zeros)
         ma_Zeros(i) = String$(i, "0")
      Next i

      s_Initialized = True
   End If

   If p_FlattenWhitespace Then
      p_String = stringsFlattenWhitespace(p_String, p_TrimType)
      
   Else
      If p_TrimType = stringtt_Both Then
         ' Leading and trailing spaces will be removed
         p_String = Trim$(p_String)
      ElseIf p_TrimType = stringtt_Left Then
         p_String = LTrim$(p_String)
      ElseIf p_TrimType = stringtt_Right Then
         p_String = RTrim$(p_String)
      End If
   End If

   l_Len = LenB(p_String)      ' We will be looping through the entire length of
   ' the string using the Byte version of string manipulation functions (slight speed increase)
   If l_Len = 0 Then
      ' Short-circuit, nothing left to process
      Exit Function
   End If

   ' Initialize a buffer that will cover the max length of the converted string
   stringsConvertToSmartSortString = Space$(Int(l_Len / 4 + 0.5) * (mc_PadLength + 1))
   
   Dim SA1DBuff As SAFEARRAY1D
   Dim SA1DSrc As SAFEARRAY1D
   Dim iCharsBuff() As Integer
   Dim iCharsSrc() As Integer
   
   With SA1DBuff
      .cDims = 1
      .fFeatures = FADF_AUTO Or FADF_FIXEDSIZE
      .cbElements = 2&
      .cLocks = 1&
      .lLbound = 1&
      .pvData = StrPtr(stringsConvertToSmartSortString)
      .cElements = Len(stringsConvertToSmartSortString)
   End With
   
   PutMem4 VarPtrArray(iCharsBuff), VarPtr(SA1DBuff)
   
   With SA1DSrc
      .cDims = 1
      .fFeatures = FADF_AUTO Or FADF_FIXEDSIZE
      .cbElements = 2&
      .cLocks = 1&
      .lLbound = 1&
      .pvData = StrPtr(p_String)
      .cElements = Len(p_String)
   End With
   
   PutMem4 VarPtrArray(iCharsSrc), VarPtr(SA1DSrc)
   
   Dim l_InNumber As Boolean
   Dim l_StartNumber As Long
   Dim j As Long
   
   l_NextIndex = l_NextIndex + 1
   
   For i = 1 To Len(p_String)
      Select Case iCharsSrc(i)
      Case 48 To 57  ' 0 to 9
         If Not l_InNumber Then
            l_InNumber = True
            l_StartNumber = i
         End If
      
      Case Else
         If l_InNumber Then
            For j = 1 To 32 - (i - l_StartNumber)
               iCharsBuff(l_NextIndex) = 48
               l_NextIndex = l_NextIndex + 1
            Next j
            For j = l_StartNumber To i - 1
               iCharsBuff(l_NextIndex) = iCharsSrc(j)
               l_NextIndex = l_NextIndex + 1
            Next j
            
            iCharsBuff(l_NextIndex) = iCharsSrc(i)
            l_NextIndex = l_NextIndex + 1
            
            l_InNumber = False
            
         Else
            iCharsBuff(l_NextIndex) = iCharsSrc(i)
            l_NextIndex = l_NextIndex + 1
         End If
         
      End Select
   Next i

   If l_InNumber Then
      For j = 1 To 32 - (i - l_StartNumber)
         iCharsBuff(l_NextIndex) = 48
         l_NextIndex = l_NextIndex + 1
      Next j
      For j = l_StartNumber To i - 1
         iCharsBuff(l_NextIndex) = iCharsSrc(j)
         l_NextIndex = l_NextIndex + 1
      Next j
      
      l_InNumber = False
   End If

   PutMem4 VarPtrArray(iCharsBuff), 0&
   PutMem4 VarPtrArray(iCharsSrc), 0&
   
   stringsConvertToSmartSortString = LCase$(Left$(stringsConvertToSmartSortString, l_NextIndex - 1))
   
End Function

Public Function stringsTrimWhitespace(ByVal p_Text As String) As String
   Dim i As Long
   Dim l As Long
   Dim j As Long

   l = Len(p_Text)

   If l > 0 Then
      For i = 1 To l
         Select Case AscW(Mid$(p_Text, i, 1))
         Case 9, 10, 11, 12, 13, 32, 160
         Case Else
            Exit For
         End Select
      Next i
   
      If i < l Then
         For j = l To 1 Step -1
            Select Case AscW(Mid$(p_Text, j, 1))
            Case 9, 10, 11, 12, 13, 32, 160
            Case Else
               Exit For
            End Select
         Next j
      End If
   
      If j >= 1 Then
         'If j > 0 Then
         If (i <> 1) Or (j <> l) Then
            stringsTrimWhitespace = Mid$(p_Text, i, j - i + 1)
         Else
            stringsTrimWhitespace = p_Text
         End If
         'End If
      ElseIf i > 1 Then
         stringsTrimWhitespace = Mid$(p_Text, i)
      Else
         stringsTrimWhitespace = p_Text
      End If
   End If
End Function

Public Function stringsIsEmptyOrWhitespaceOnly(p_Text As String) As Boolean
   Dim SA1D As SAFEARRAY1D
   Dim iChars() As Integer
   Dim i As Long
   Dim l As Long

   stringsIsEmptyOrWhitespaceOnly = True
   
   l = Len(p_Text)
   
   If l Then
      With SA1D
         .cDims = 1
         .fFeatures = FADF_AUTO Or FADF_FIXEDSIZE
         .cbElements = 2&
         .cLocks = 1&
         .lLbound = 1&
      End With
   
      PutMem4 VarPtrArray(iChars), VarPtr(SA1D)
   
      SA1D.pvData = StrPtr(p_Text)
      SA1D.cElements = l
      
      For i = 1 To l
         Select Case iChars(i)
         Case 9, 10, 11, 12, 13, 32, 160
         Case Else
            stringsIsEmptyOrWhitespaceOnly = False
            
            Exit For
         End Select
      Next i
   
      PutMem4 VarPtrArray(iChars), 0&
   End If
End Function

Public Function stringsFlattenWhitespace(ByVal pText As String, Optional ByVal p_TrimType As e_StringTrimType) As String
'---------------------------------------------------------------------------------------
' Procedure  : FlattenWhitespace
' DateTime   : February 26, 2018
' Author     :  Victor Bravo VI here: http://www.vbforums.com/showthread.php?859471-SuperTrim-Function-for-strings&p=5266167&viewfull=1#post5266167
'               Enhancements to handle different "whitespace" characters
'               and optional trimming by Jason Peter Brown (jason@bitspaces.com)
' Purpose    : To convert all non-space whitespace chars to spaces and convert two or more
'              spaces in a row to a single space. Optionally trimming leading,
'              trailing or both leading and trailing whitespace
' Parameters : pText - Text to flatten
'              pTrim - stringTrimType Enum.
'                      stringTTNone - Don't trim leading or trailing whitespace
'                      stringTTLeft - Trim leading whitespace
'                      stringTTRight - Trim trailing whitespace
'                      stringTTBoth - Trim leading and trailing whitespace
' Returns    : Whitespace flattened (and optionally trimmed) string
'---------------------------------------------------------------------------------------

   Dim i As Long, j As Long, k As Long

   Dim SA1D As SAFEARRAY1D
   Dim iChars() As Integer

   k = Len(pText)

   If k = 0 Then Exit Function  ' No string data to trim

   With SA1D
      .cDims = 1
      .fFeatures = FADF_AUTO Or FADF_FIXEDSIZE
      .cbElements = 2&
      .cLocks = 1&
      .lLbound = 1&
   End With

   PutMem4 VarPtrArray(iChars), VarPtr(SA1D)

   SA1D.pvData = StrPtr(pText)
   SA1D.cElements = k
   i = 1&

   'Trim leading spaces
   Select Case iChars(i)
   Case Is < 33, 160
      If (p_TrimType And stringtt_Left) <> stringtt_Left Then
         ' Not trimming left side,
         ' so nudge collapse point ahead 1 characters
         j = 1
      End If

      For i = i To SA1D.cElements
         Select Case iChars(i)
         Case 32
         Case 160, Is < 32
            ' Convert non-space whitespace to space
            iChars(i) = 32
         
         Case Else
            Exit For
         
         End Select
      Next i
   End Select

   For i = i To SA1D.cElements
      j = j + 1&
      iChars(j) = iChars(i)

      Select Case iChars(i)
      Case Is < 33, 160
         For k = i To SA1D.cElements
            Select Case iChars(k)
            Case 32
            
            Case 160, Is < 32
               ' Convert non-space whitespace to space
               iChars(k) = 32
               
            Case Else
               Exit For
            
            End Select
         Next k

         i = k - 1&
      End Select
   Next i

   'Trim trailing spaces
   If j Then
      If p_TrimType And stringtt_Right Then
         Select Case iChars(j)
         Case Is < 33, 160
            j = j - 1
         End Select
      End If
      
      If j Then
         stringsFlattenWhitespace = Left$(pText, j)
      End If
   End If
   
   PutMem4 VarPtrArray(iChars), 0&
End Function

Public Function stringsRemoveWhitespace(ByVal p_Text As String) As String
   Dim SA1D As SAFEARRAY1D
   Dim iChars() As Integer
   Dim i As Long
   Dim l As Long
   Dim o As Long
   
   l = Len(p_Text)
   
   If l Then
      With SA1D
         .cDims = 1
         .fFeatures = FADF_AUTO Or FADF_FIXEDSIZE
         .cbElements = 2&
         .cLocks = 1&
         .lLbound = 1&
         .pvData = StrPtr(p_Text)
         .cElements = l
      End With
      
      PutMem4 VarPtrArray(iChars), VarPtr(SA1D)
         
      For i = 1 To l
         Select Case iChars(i)
         Case 0 To 32, 160
            o = o + 1
         
         Case Else
            If o > 0 Then iChars(i - o) = iChars(i)
         End Select
      Next i
     
      PutMem4 VarPtrArray(iChars), 0&
   
      If o Then
         stringsRemoveWhitespace = Left$(p_Text, l - o)
      Else
         stringsRemoveWhitespace = p_Text
      End If
   End If
End Function

Public Function stringsLogicalLineTypeName(ByVal p_LogicalLineType As e_LogicalLineType) As String
   Select Case p_LogicalLineType
   Case logicallinetype_Empty
      stringsLogicalLineTypeName = "Empty"
      
   Case logicallinetype_Header
      stringsLogicalLineTypeName = "Header"
   
   Case logicallinetype_Attribute
      stringsLogicalLineTypeName = "Attribute"
    
   Case logicallinetype_Option
      stringsLogicalLineTypeName = "Option"
   
   Case logicallinetype_ConditionalCompilation
      stringsLogicalLineTypeName = "Conditional Compilation"
   
   Case logicallinetype_Comment
      stringsLogicalLineTypeName = "Comment"
   
   Case logicallinetype_ApiDeclaration
      stringsLogicalLineTypeName = "API Declaration"
   
   Case logicallinetype_VariableDeclaration
      stringsLogicalLineTypeName = "Variable Declaration"
   
   Case logicallinetype_MethodStart
      stringsLogicalLineTypeName = "Method Start"
   
   Case logicallinetype_MethodEnd
      stringsLogicalLineTypeName = "Method End"
   
   Case logicallinetype_Statement
      stringsLogicalLineTypeName = "Statement"
   
   Case logicallinetype_Label
      stringsLogicalLineTypeName = "Label"
   
   Case logicallinetype_EnumStart
      stringsLogicalLineTypeName = "Enum Start"
   
   Case logicallinetype_EnumMember
      stringsLogicalLineTypeName = "Enum Member"
   
   Case logicallinetype_EnumEnd
      stringsLogicalLineTypeName = "Enum End"
   
   Case logicallinetype_TypeStart
      stringsLogicalLineTypeName = "Type Start"
   
   Case logicallinetype_TypeMember
      stringsLogicalLineTypeName = "Type Member"
   
   Case logicallinetype_TypeEnd
      stringsLogicalLineTypeName = "Type End"
   
   Case logicallinetype_ConstantDeclaration
      stringsLogicalLineTypeName = "Constant Declaration"
   
   Case Else
      ' Unhandled! Handle this type.
      
      Debug.Assert False
      stringsLogicalLineTypeName = "Unknown: " & p_LogicalLineType
   End Select
End Function

Public Function stringsVbpTokenTypeName(ByVal p_TokenType As e_VbpTokenType) As String
   Select Case p_TokenType
   Case vbptokentype_Module
      stringsVbpTokenTypeName = "Module"
   Case vbptokentype_Form
      stringsVbpTokenTypeName = "Form"
   Case vbptokentype_Class
      stringsVbpTokenTypeName = "Class"
   Case vbptokentype_UserControl
      stringsVbpTokenTypeName = "User Control"
   Case vbptokentype_Reference
      stringsVbpTokenTypeName = "Reference"
   Case vbptokentype_Component
      stringsVbpTokenTypeName = "Component"
   Case vbptokentype_PropertyPage
      stringsVbpTokenTypeName = "Property Page"
   Case vbptokentype_ResourceFile
      stringsVbpTokenTypeName = "Resource File"
   Case Else
      Debug.Assert False
      stringsVbpTokenTypeName = "Unknown: " & p_TokenType
   End Select
End Function
