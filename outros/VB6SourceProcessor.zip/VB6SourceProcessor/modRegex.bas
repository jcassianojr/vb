Attribute VB_Name = "modRegex"
Option Explicit

Public Type Matches
   FoundMatch As Boolean
   MatchStart As Long
   MatchLen As Long
   Match As String
   SubMatchCount As Long
   SubMatches() As String
End Type

Private Declare Sub win32_CopyMemory Lib "kernel32.dll" Alias "RtlMoveMemory" (ByRef Destination As Any, ByRef Source As Any, ByVal Length As Long)

Public Function RegexSplit(ByVal p_TextToSplit As String, Optional ByVal p_RegexToMatch As String) As String()
   Dim la_Split() As String
   Dim l_NextIndex As Long
   
   Do
      With RegexMatch(p_TextToSplit, p_RegexToMatch)
         If .FoundMatch Then
            ' Found a match
            
            ' Make sure we have enough space for text in our result arrya
            If l_NextIndex = 0 Then
               ReDim la_Split(99)
            ElseIf l_NextIndex > UBound(la_Split) Then
               ReDim Preserve la_Split(l_NextIndex * 2)
            End If
            
            la_Split(l_NextIndex) = Left$(p_TextToSplit, .MatchStart - 1)
            p_TextToSplit = Mid$(p_TextToSplit, .MatchStart + .MatchLen)
            
            l_NextIndex = l_NextIndex + 1
         
         Else
            ' No match found, exit loop
            Exit Do
         End If
      End With
   Loop
   
   If l_NextIndex = 0 Then
      ReDim la_Split(0)
      la_Split(0) = p_TextToSplit
   Else
      If Len(p_TextToSplit) Then
         If UBound(la_Split) < l_NextIndex Then ReDim Preserve la_Split(l_NextIndex)
         
         la_Split(l_NextIndex) = p_TextToSplit
         
         l_NextIndex = l_NextIndex + 1
      End If
      
      ReDim Preserve la_Split(l_NextIndex - 1)
   End If
   
   RegexSplit = la_Split
End Function

Public Function RegexMatch(ByVal p_TextToSearch As String, Optional ByVal p_RegexToMatch As String, Optional ByVal p_CaseSensitive As Boolean = False) As Matches
   ' Returns a Match UDT
   
   ' If .Matched = False then no matches were found
   ' If .Matched = True then:
   ' A match was found (with possible submatches depending on the regex).
   '    The full matched text will be stored in .Match as a string
   '    If there are sub-matches, then SubMatch count will be > 0
   '    You can retrieve sub-matches from the .SubMatches member using one-based indexing
   '    so .SubMatches(1) will return sub-match #1, .SubMatches(2) will return sub-match #2, etc...
   '    If .SubMatchCount = 0 then .SubMatches will not be dimensioned, so do not try to access it.
   
   Dim l_CompiledContextHandle As Long
   Dim l_CompiledRegexHandle As Long
   Dim l_MatchDataHandle As Long
   Dim l_MatchContextHandle As Long
   
   Dim l_ErrorNumber As Long
   Dim l_ErrorDesc As String
   Dim l_MatchCount As Long
   Dim l_OvectorPtr As Long
   Dim la_Ovector() As Long
   Dim l_StrPtr As Long
   Dim l_ErrorCode As Long
   Dim l_ErrorPosition As Long
   Dim l_MatchStart As Long
   Dim l_MatchLen As Long
   Dim l_Flags As Long
   
   Dim ii As Long ' Loop counter
      
   'On Error GoTo ErrorHandler
   
   l_CompiledContextHandle = pcre2_compile_context_create(0)
   If l_CompiledContextHandle = 0 Then Err.Raise "Could not compile PCRE context! Last DLL Error: " & Err.LastDllError
   
   If Not p_CaseSensitive Then
      l_Flags = PCRE_CO_CASELESS
   End If
   l_CompiledRegexHandle = pcre2_compile(StrPtr(p_RegexToMatch), Len(p_RegexToMatch), l_Flags, l_ErrorCode, l_ErrorPosition, l_CompiledContextHandle)
   If l_CompiledRegexHandle = 0 Then Err.Raise vbObjectError, , "Could not compile regex! Regex: " & p_RegexToMatch & vbNewLine & "Errorcode: " & l_ErrorCode & ", Error Position: " & l_ErrorPosition
   
   l_MatchDataHandle = pcre2_match_data_create_from_pattern(l_CompiledRegexHandle, 0)
   If l_MatchDataHandle = 0 Then Err.Raise vbObjectError, , "Could not allocate match data! Last DLL Error: " & Err.LastDllError
   
   l_StrPtr = StrPtr(p_TextToSearch)
   If l_StrPtr = 0 Then l_StrPtr = StrPtr("")
   
   l_MatchCount = pcre2_match(l_CompiledRegexHandle, l_StrPtr, Len(p_TextToSearch), 0, 0, l_MatchDataHandle, l_MatchContextHandle)
   
   Select Case l_MatchCount
   Case PCRE2_ERROR_NOMATCH
      ' No matches, that's normal :)
   
   Case Is > 0
      ' Number of matches, store information about matches
      l_OvectorPtr = pcre2_get_ovector_pointer(l_MatchDataHandle)
      
      If l_OvectorPtr = 0 Then
         ' Shouldn't happen!
         Err.Raise vbObjectError, , "Ovector pointer could not be retrieved!"
      End If
      
      win32_CopyMemory l_MatchStart, ByVal l_OvectorPtr, 4
      win32_CopyMemory l_MatchLen, ByVal (l_OvectorPtr + 4), 4
      l_MatchLen = l_MatchLen - l_MatchStart
      
      ReDim la_Ovector(2 * l_MatchCount - 1)

      win32_CopyMemory la_Ovector(0), ByVal l_OvectorPtr, 2 * l_MatchCount * 4
      
      With RegexMatch
         .FoundMatch = l_MatchCount
         .MatchStart = la_Ovector(0) + 1
         .MatchLen = la_Ovector(1) - la_Ovector(0)
         .Match = Mid$(p_TextToSearch, .MatchStart, .MatchLen)
         
         .SubMatchCount = l_MatchCount - 1
         
         If l_MatchCount > 1 Then
            ReDim .SubMatches(1 To l_MatchCount - 1)
         
            For ii = 1 To l_MatchCount - 1
               l_MatchStart = la_Ovector(ii * 2) + 1
               l_MatchLen = la_Ovector(ii * 2 + 1) - l_MatchStart + 1
               If l_MatchLen > 0 Then
                  .SubMatches(ii) = Mid$(p_TextToSearch, l_MatchStart, l_MatchLen)
               End If
            Next ii
         End If
      End With
                        
   Case Else
      ' Uhoh! We need to handle these
      Err.Raise vbObjectError - l_MatchCount, , "PCRE Match Error: " & l_MatchCount
      
   End Select
   
Cleanup:
   'On Error Resume Next

   ' Free match data if necessary
   If l_MatchContextHandle <> 0 Then pcre2_match_context_free l_MatchContextHandle: l_MatchContextHandle = 0
   If l_MatchDataHandle <> 0 Then pcre2_match_data_free l_MatchDataHandle: l_MatchDataHandle = 0
   If l_CompiledRegexHandle <> 0 Then pcre2_code_free l_CompiledRegexHandle: l_CompiledRegexHandle = 0
   
   'Free compile context before exiting
   If l_CompiledContextHandle <> 0 Then pcre2_compile_context_free l_CompiledContextHandle: l_CompiledContextHandle = 0

   If l_ErrorNumber <> 0 Then
      If IsPcre2ErrorCode(l_ErrorNumber) Then
         l_ErrorDesc = l_ErrorDesc & vbNewLine & "PCRE2 Error Message: " & GetPcre2ErrorMessage(l_ErrorNumber)
      Else
         If IsPcre2ErrorCode(vbObjectError - l_ErrorNumber) Then
            l_ErrorDesc = l_ErrorDesc & vbNewLine & "PCRE2 Error Message: " & GetPcre2ErrorMessage(vbObjectError - l_ErrorNumber)
         End If
      End If
      
      On Error GoTo 0
      Err.Raise l_ErrorNumber, , l_ErrorDesc
   End If

   Exit Function

ErrorHandler:
   l_ErrorNumber = Err.Number
   l_ErrorDesc = Err.Description
   
   Debug.Assert False
   Resume Cleanup
End Function

Private Function IsPcre2ErrorCode(ByVal p_ErrorCode As Long) As Boolean
   IsPcre2ErrorCode = (p_ErrorCode <= [_PCRE_RC_ERROR_FIRST] And p_ErrorCode >= [_PCRE_RC_ERROR_LAST])
End Function

Private Function GetPcre2ErrorMessage(ByVal p_ErrorCode As Long) As String
   Dim l_BufferLength As Long
   Dim l_Buffer As String
   Dim l_MessageLength As Long
   
   l_BufferLength = 256
   
   Do
      l_Buffer = Space$(l_BufferLength)
      
      l_MessageLength = pcre2_get_error_message(p_ErrorCode, StrPtr(l_Buffer), l_BufferLength)
      
      If l_MessageLength < 0 Then
         Select Case l_MessageLength
         Case PCRE_RC_ERROR_NOMEMORY
            ' Buffer too small
            l_BufferLength = l_BufferLength * 2
         Case PCRE_RC_ERROR_BADDATA
            ' Bad error code
            
            Exit Do
         Case Else
            Debug.Assert False
            Exit Do
            
         End Select
      End If
   Loop While l_MessageLength < 0
   
   If l_MessageLength < 0 Then
      GetPcre2ErrorMessage = "Unknown error #" & p_ErrorCode & ", PCRE2 error message result #" & l_MessageLength
   Else
      GetPcre2ErrorMessage = Left$(l_Buffer, l_MessageLength)
   End If
End Function

