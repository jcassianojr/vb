Attribute VB_Name = "modOptions"
Option Explicit

Public Function optRunConfirmationSeconds() As Long
   ' Return > 0 to force a confirmation window to appear when the RUN button is clicked (before processing source files).
   '     The "Run" button with be disabled for the number of seconds you return
   ' Return 0 to immediately begin processing after the RUN button is clicked.
   ' Return -1 (True) to show a confirmation window, but without a disabled button for any amount of time
   
   optRunConfirmationSeconds = 0
End Function

Public Function optShowVbpParseTiming() As Boolean
   optShowVbpParseTiming = False
End Function

Public Function optLazyParseLogicalLines() As Boolean
   ' Return TRUE to parse logical lines in source files only when logical line properties are accessed.
   ' Return FALSE to parse logical lines in source files when as they are being loaded
   optLazyParseLogicalLines = True
End Function

