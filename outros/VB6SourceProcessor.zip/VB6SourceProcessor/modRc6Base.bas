Attribute VB_Name = "modRc6Base"
Option Explicit

' *** ACKNOWLEDGEMENTS **
' None of this work is useful without the prior hard work of Olaf Schmidt. Get RC6 at https://www.vbrichclient.com/
' Some of this code is based on earlier work by Olaf Schmidt (in particular the New_C method code).
' The "Running in IDE" detection code is the work of Vladislav Petrovsky.
' The "Enum PTR" alias trick is the work of someone named "OlimilO1402".
' All the rest was coded and commented by Jason Brown.

' *** INTRODUCTION ***

' THE PRIMARY GOAL OF THIS MODULE is to be universal and foundational code for VB6 apps
' using DirectCOM.dll and RC6.dll to instantiate ActiveX objects without requiring the use of
' regsvr32/installers on your application's end users' computers.
' This approach will be called "DirectCOM reg-free" or simply "reg-free" for the rest of this document.

' By "Universal" I mean that this module should be added to EVERY VB6/RC6 project.
' By "Foundational" I mean that this module should be the FIRST THING that you add
'                   to every project you create that will be using RC6/DirectCOM reg-free.

' CAVEAT EMPTOR - This is a work in progress! There may be bugs!
'                 Use at your own risk, no warranties express or implied.

' IMPORTANT: If you are already successfully using Microsoft SxS application manifests,
' Or an "installler" app that registers all of your apps dependencies,
' then you do NOT need DirectCOM reg-free, and you can ignore this module completely.

' *** ABOUT DIRECTCOM REGISTRY-FREE TECHNOLOGY ***

' DirectCOM "registry free" ActiveX/COM object instantiation was developed by Olaf Schmidt.
' It as an alternative Microsoft's standard SxS application manifests technology.

' Both reg-free technologies allow your VB6 apps to use ActiveX DLL class objects
' *without* requiring them to be registered on your end users' computers.

' Both technologies have their advantages and disadvantages,
' It is important to read ALL of the following comments to decide if DirectCOM reg-free is the right choice for you.

' IMO main advantage of DirectCOM reg-free over Microsoft's SxS is that it is 100% useable wihtin you existing source code,
' using familiar VB6 syntax, whereas Micrsoft SxS requires a separate XML file, and knowledge of external tools is required.


' *** DEFINITIONS ***

' Dev Box/Dev Machine/Dev Computer - Short-form for your development computer.
'                                    This is one (or more) computers/virtual machines/systems where you (or your team/company)
'                                    are developing your source code with the VB6 IDE installed.

' User's Computer - Any system where your compiled software is running (not including any dev box(es) where VB6 is installed)
'                   That is, any computer/virtual machine/system that is NOT your "Dev Box"


' *** IMPORTANT! ***
' For this code to work on your dev box, you must:

' 1) Have RC6.dll properly registered on your dev box, AND
' 2) Have a reference to RC6 selected in the VB6 Project menu > References window.

' There are a few things you must consider to make your project fully and properly regfree using the RC6 approach:

' 1) The regular VB6 "New" keyword should ONLY be used for instantiating objects that you know:
'     A) WILL ALWAYS be registered on the target computer even if you don't distribute/register them
'            (e.g. Windows system DLL objects that are always distributed with the OS), OR
'
'     B) Are intrinsic VB6/STDOLE objects (like the Collection, StdFont, StdPicture, etc... objects), OR
'
'     C) Are classes within your own project...
'            ...For example, if you have an ActiveX DLL named MyDll with a public class called MyClass, then
'
'            INSIDE the MyDll project, you should always instantiate it with "Set MyObj = New MyDll.MyClass" (NOT by using any of the reg-free methods!)
'
'            OUTSIDE of the MyDll project (e.g. in another VB6 project that references MyDll),
'                    you should use the regfree CreateObjectRegFree method (described more in point #4 below).
'
' 2) If you want to instantiate a non-Cairo RC6 object (e.g. cCollection, cRecordset, etc...), then
'    ALWAYS use the New_C.<ClassName> method INSTEAD of the regular VB6 New keyword.
'    For example, if you want to instantiate an RC6 cRecordset object, use "Set RS = New_C.Recordset"
'
' 3) If you want to instantiate a Cairo RC6 object (e.g. cCairoSurface), then
'    ALWAYS use the Cairo.<MethodThatCreatesACairoObject> method INSTEAD of the regular VB6 New keyword.
'    For exampe, "Set MySrf = Cairo.CreateSurface(100,100)" ' Creates a 100x100 pixel Cairo image surface.
'
' 4) If you want to instantiate any object from any reference not described above,
'           ALWAYS use the CreateObjectRegFree() method.
'           For Example, for one of your own DLLs (or a non-Windows third-party DLL), use:
'                        Set Obj = CreateObjectRegFree("MyDll.dll", "MyClass") in code outside of MyDll.dll
'           See the CreateObjectRegFree method comments below for more details.
'
' *** MORE IMPORTANT REG-FREE NOTES ***
'
' For DirectCOM reg-free instantiation to work using this module,
' you MUST have the following files in the "System" sub-folder of your main app folder:
'
'     1) RC6.dll
'     2) DirectCOM.dll
'     3) cairo_sqlite.dll
'     4) RC6Widgets.dll <OPTIONAL> - This file is only needed if you are using RC6 generated UI Forms & Widgets (aka Controls).
'                                    For standard/normal VB6 Form and ActiveX Control based apps, you DO NOT NEED RC6Widgets.dll
'
' Your application folder layout will ultimately look like this:
'
'     \MyApp\               <- This is the root application folder that can be placed in any other folder on the computer
'                              (e.g. c:\users\myusername\AppData\Local\MyCompany\MyApp\)

'     \MyApp\MyApp.exe      <- This is your main compiled App EXE that users will launch to use your software.
'                              If you have "suite" of EXEs that the user can launch, they should all be stored in this folder.
'                              Any "satellite" EXEs that your main app(s) use for tasks like background processing and that
'                              are designed for user's to launch directly themselves should NOT be stored here.
'                              Instead put your satellite EXEs in the \MyApp\System\ folder (shown below in the hierarchy)

'     \MyApp\System\        <- This folder will contain all the RC6 DLLs (as listen in the section above)
'                              AND any other DLLs that you want to use reg-free in your main app(s) and satellite app(s)
'                              This includes 3rd party DLLs like Chilkat, redistributable MS DLLs that are part of Windows
'                              that you want to access reg-free, etc...
'                              NONE of these DLLs should be registered on any user's computer.
'
'                              This folder is also where you put any "satellite" EXEs for you main app(s).
'                              Satellite EXEs are apps that your main app shells out to for any reason,
'                              but that you don't want the user to launch directly themselves.
'
'                              EXCEPTION: Do not store any DLLs here that you will access remotely over a network
'                                         using RC6 cRpcConnection/cRpcListener classes. RPC (Remote Procedure Call) DLLs
'                                         must go in the \MyApp\System\RPCDlls folder (described below).

'     \MyApp\System\RC6.dll
'     \MyApp\System\DirectCOM.dll
'     \MyApp\System\cairo_sqlite.dll
'     \MyApp\System\RC6Widgets.dll      <- This file is only needed if you have written an RC6 UI/Widgets/Controls application.
'                                          It's NOT required for regular VB6 form based apps

'     \MyApp\System\RPCDlls\     <- This is an optional folder where you should put all DLLs that you will be calling
'                                   remotely over a network using RC6's cRpcConnection and cRpcListener class objects.

' REMEMBER -
' All other non-RPC DLLs that you want to use reg-free should also be distributed  in the
' \MyApp\System folder so that the reg-free methods can find and use them.

' NONE OF THE DLLS IN \MyApp\System\ should be registered on your users' computers
' (neither by regsvr32, nor by an application installer)!

' *** END OF INTRODUCTION ***

' *** START OF CODE ***

' *** Conditional Compilation Constants ***

' UseInlineIdeCheck - When set to True, this moodule will use Vladislav Petrovsky's (aka. firehacker) nifty inline InIDE checks.
'                     When False, this module will use a more common cached App.LogMode = 0 check in a separate function.
'
'                     Petrovsky's inline approach is:
'                     A) Faster than the classic function approach
'                     B) Compiles to smaller, cleaner, more efficient binary code
'                         (all source code inside IDE checks will not be compiled into the binary EXE code!)
'
'                     Why would you ever set this conditinal compilation to False and use something that is slower and produces worse bianries?
'                     Primarily because I am unsure of the copyright status of this approach. AFAIK Petrovsky allows the use of
'                     his method as long as you give credit, but it's possible there are other strings attached

'                     If you have any concerns and would prefer to use the unencumbered tradtional VB6 approach:
'                     1) clear all the code the sits within "#If UseInlineIdeCheck Then" blocks
'                     2) remove the "#Const UseInlineIdeCheck = True" conditional compilation line (below)
'
'                     You can learn more about Petrovsky's approach here:
'                       https://www.vbforums.com/showthread.php?834231-Instantiate-internal-class-object-with-name-in-string&p=5508655&viewfull=1#post5508655
'                     And here (original discovery report in Russian):
'                       http://bbs.vbstreets.ru/viewtopic.php?f=68&t=42654

' Conditional Compilation Constants

#Const UseInlineIdeCheck = True  ' If True, we'll use Vladislav Petrovsky's (aka Firehacker) inline IDE detection scheme.
                                 ' If False, we'll use a more traditional "RunningInIDE" function.

' *** API & Related Constant/Enum Declarations

' These APIs are needed for bootstrapping reg-free instantiation via DirectCOM.DLL

Private Declare Function LoadLibraryW Lib "kernel32" (ByVal lpLibFileName As Long) As Long
Private Declare Function GetInstanceEx Lib "DirectCOM" (spFName As Long, spClassName As Long, Optional ByVal UseAlteredSearchPath As Boolean = True) As Object

' These APIs/Constants/Enums are required for determining whether or not a file exists before we have bootstrapped RC6 reg-free
' and for determine the path of the image containing this module (unicode capable App.Path replacement)
' and also for a unicode-aware top-level module path function (PathApp - this is the path to the main EXE even when this module is used in a DLL)

Private Declare Function GetFileAttributes Lib "kernel32" Alias "GetFileAttributesW" (ByVal spFPath As Long) As Long
Private Declare Function GetModuleHandleEx Lib "kernel32" Alias "GetModuleHandleExW" (ByVal dwFlags As Long, ByVal lpModuleName As Long, ByRef hModule As Any) As Long
Private Declare Function GetModuleFileName Lib "kernel32" Alias "GetModuleFileNameW" (ByVal hModuleHandle As Long, ByVal lpName As Long, ByVal nSize As Long) As Long

Private Const INVALID_FILE_ATTRIBUTES As Long = -1
Private Const ERROR_FILE_NOT_FOUND As Long = 2
Private Const ERROR_PATH_NOT_FOUND As Long = 3
Private Const MAX_PATH As Long = 260
Private Const MAX_LONG_PATH As Long = 32767
Private Const GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS As Long = 4
Private Const GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT As Long = 2

Private Const ERROR_INSUFFICIENT_BUFFER As Long = 122

' *** Methods ***

Public Function New_C() As RC6.cConstructor
   ' This function will override the RC6.dll's Global New_C method in your project.
   ' This ensures there is no need to declare a New_C variable anywhere else in your project
   ' Nor will there be any need to instantiate any cConstructor objects via the New keyword.
   '
   ' This function can create/instantiate any RC6 class, so it should be used instead of the intrinsic VB6 New keyword
   '
   ' DO NOT use the New keyword to create new cConstructors or new RC6 objects like cRecordset, cConnection, cArrayList, etc...
   ' just call New_C.<ObjectYouWantToContruct> to create new RC6 objects when needed.
   '
   ' i.e. None of the following BAD examples of instantiation should be used ANYWHERE in your app:
   '
   '  BAD:
   '     A) Dim New_C As New cConstructor
   '     B) Dim New_C As cConstructor: Set New_C = New cConstructor
   '     C) Dim RS As New cRecordset
   '     D) Dim RS As cRecordset: Set RS = New cRecordSet
   '
   '  Instead, you follow these good approaches to the above:
   '
   '  GODD:
   '     A) Never create new cConstructors, it's not necessary. Just uuse New_C directly as a global reference.
   '     B) Never create new cConstructors, it's not necessary. Just use New_C directly as a global reference.
   '     C) Dim RS As cRecordset: Set RS = New_C.Recordset    ' Declares an uninstantiated cRecordset by the name of RS (initially set to Nothing)
   '                                                          ' Then subsequently instantiates a new cRecordset object (registry-free through the New_C cConstructor object)
   '                                                          ' and then assigns it to the RS variable using the Set keyword.
   '     D) Same as C) above
   '
   ' IMPLEMENTATION NOTE: This version of New_C will use the registry to create an instance while running in the IDE,
   '                      But will attempt reg-free instantiation when run as a compiled executable.
   '                      This means you MUST have RC6.dll registered on your dev box,
   '                      But SHOULD NOT register RC6.dll on user's computers.
   
   Static so_NewC As RC6.cConstructor  ' Holds a cConstructor reference so we only have to instantiate it once
   
   Dim l_InIde As Boolean
   
#If UseInlineIdeCheck Then
   Debug.Assert MakeTrue(l_InIde)
#Else
   l_InIde = RunningInIde
#End If

   If so_NewC Is Nothing Then
      ' We have no cConstructor object yet, so let's create one
      ' We use a Static variable so instantiation only occurs a maximum of ONE-TIME in the app lifetype
   
      If l_InIde Then
         ' In the IDE we'll use the normal VB6 New keyword to instantiate via the registry
         Set so_NewC = New RC6.cConstructor
         
      Else
         ' When running compiled (i.e. not in the IDE), we will first attempt regfree instantiation via DirectCOM.dll
         ' If that fails we will ask the user if they want to attempt to use the registry to instantiate.
         ' If any users see the message that asks permission to "Retry", you should consider this a bug in your
         ' deployment and make sure you have configured your App & App\System folders properly as described above.
         
         On Error Resume Next
         LoadLibraryW StrPtr(PathAppSystem & "DirectCOM.dll")
         Set so_NewC = GetInstanceEx(StrPtr(PathAppSystem & "RC6.dll"), StrPtr("cConstructor"))
         If so_NewC Is Nothing Then Set so_NewC = GetInstanceEx(StrPtr(PathImage & "\RC6.dll"), StrPtr("cConstructor"))  ' Couldn't find RC6.dll where we expected to, try current app path
         If so_NewC Is Nothing Then Set so_NewC = GetInstanceEx(StrPtr(PathImage & "\System\RC6.dll"), StrPtr("cConstructor")) ' Still couldn't find RC6.dll where we expected to, try current App Path\System\
         On Error GoTo 0
         
         If so_NewC Is Nothing Then
            ' UhOh! We couldn't create a cConstructor object reg-free!
            ' Let's try using the registry as a fallback plan
            ' If users see a message box warning that the Constructor couldn't be created,
            ' Then you will know you haven't deployed your RC6 DLLs properly.
            ' You should fix this rather then rely on the registry.
            ' See the IMPORTANT REG-FREE NOTES near the top of this module for details.
            
            Select Case MsgBox("Installation Error! Could not create Constructor object!", vbRetryCancel, "Installation Error!")
            Case vbRetry
               ' Try to use the registry to get a RC6.cConstructor object
               ' This indicates an installation or app\system folder configuration problem
               ' But we'll giveit a last ditch effort in case the user has RC6.dll registered somewhere
               On Error Resume Next
               Set so_NewC = New RC6.cConstructor
               On Error GoTo 0
            End Select
            
            If so_NewC Is Nothing Then
               ' Still no cConstructor! This means we couldn't even create an instance using the registry (or the user cancelled the attempt)
               Err.Raise vbObjectError, , "Installation error! A Constructor object could not be created."
            End If
         End If
      End If
   End If
   
   Set New_C = so_NewC  ' Return our instantiated cConstructor object reference.
End Function

Public Function Cairo() As RC6.cCairo
   ' This function will override the RC6.dll's Global Cairo method in your project.
   ' This ensures there is no need to declare a Cairo variable anywhere else in your project
   ' Nor will there be any need to instantiate any new cCairo objects anywhere in your project via the New keyword.
   '
   ' DO NOT use the New keyword to create new cCairo objects,
   ' just call Cairo.<CairoMethod> to create new Cairo objects and work against Cairo Surfaces/Contexts when needed.
   
   ' The Cairo object won't be created unless it is used at least once, so there's almost no overhead to having it
   ' sitting around in projects that don't use Cairo. That said you can delete this function if you don't use Cairo,
   ' it won't cause any problems to omit it.
   
   Static so_Cairo As RC6.cCairo
   
   ' Instantiate a cCairo reference and put it so_Cairo if this hasn't already been done
   ' (we use a Static variable so instantiation only occurs a maximum of ONE-TIME in the app lifetype)
   
   If so_Cairo Is Nothing Then Set so_Cairo = New_C.Cairo
   
   Set Cairo = so_Cairo ' Return our instantiated cCairo object reference
End Function

Public Function CreateObjectRegfree(ByVal p_DllName As String, ByVal p_ClassName As String, Optional ByVal p_ProgId As String = vbNullString) As Object
   ' Call this method to instantiate non-RC6.dll objects registry-free.
   ' This method replaces VB6's New keyword and CreateObject() method.
   ' All non-Cairo RC6.dll objects should be created with the New_C.<ClassName> method.
   ' All Cairo RC6.dll obejcts shuold be created with the Cairo.<CreateMethod> method
   ' For other DLLs, you can use this method like this:
   '
   ' Example #1, a Chilkat v.9.5 ChilkatCrypt2 object can be instantiated reg-free like this:
   '
   ' First, make sure that ChilkatAx-9.5.0-win32.dll is in the App\System folder
   ' Then when you want to create the ChilkatCrypt2 Object;
   '
   '     Dim MyCrypt As ChilkatCrypt2
   '     Set MyCrypt = CreateObjectRegFree("ChilkatAx-9.5.0-win32.dll", "ChilkatCrypt2")
   '
   ' Example #2, one of your own classes in a separate ActiveX DLL that is part of this app's project group.
   '             The DLL is called MyDllV2.dll, and the class you want to create is MyClass.cls
   '             The ProgID for the class you want to create is MyDll.MyClass
   '
   '     Dim MyClassRef As MyDll.MyClass
   '     Set MyClassRef = CreateObjectRegFree("MyDllV2.dll", "MyClass", "MyDll.MyClass")
   '
   ' Notice an extra (optional) third parameter (the ProgID of the object, MyDll.MyClass) in the second example when compared to the first.
   ' This is the object's ProgID. We pass it so when our DLL file name is different from our DLL project name
   ' This parameter can be skipped if your DLL filename is the same as your DLL project name (as we will be able to "guess" the ProgID programmatically)
   
   ' You should only pass the ProgID for DLLs/Classes where you have the VB6 source code and can run it in the IDE.
   ' For closed-source 3rd-party DLLs, there's never a need to pass the ProgID.
   '
   ' We pass it so that we can debug more easily with breakpoints/edit & continue/etc... in the IDE.
   ' The ProgID parameter will be ignored when we are running compiled, and reg-free instatiation will be used instead.
     
   Dim l_LongPath As Boolean  ' If True, we have a long path that will need a \\?\ prefix
   Dim l_ShortUnc As Boolean  ' If True, we have a short UNC path that might need to be converted to a long UNC path with \\?\UNC prefix
   Dim l_InIde As Boolean
   
#If UseInlineIdeCheck Then
   Debug.Assert MakeTrue(l_InIde)
#Else
   l_InIde = RunningInIde
#End If
   
   If l_InIde Then
      ' If we're running in the IDE
      ' We'll first try to instantiate the object using the Registry/VB6 CreateObject method.
      
      ' WHY? So we can debug our own ActiveX DLL classes with edit & continue in the IDE.
   
      ' We will attempt to guess the ProgID.
      ' This method only works if your DLL filename is the same as your DLL project name
      ' So I recommend making sure you keep those names in sync.
      ' In cases where there's a difference, you should pass the correct ProgID to the optional p_ProgId parameter
      ' That will override this guesswork.
      
      If p_ProgId = vbNullString Then
         ' No ProgID was passed, let's guess what the ProgID might be based on the passed filename & class name
         
         p_ProgId = New_C.FSO.GetFileNameFromFullPath(p_DllName)  ' Get the filename portion of the passed DLL
         If LCase$(Right$(p_ProgId, 4)) = ".dll" Then p_ProgId = Left$(p_ProgId, Len(p_ProgId) - 4)   ' Strip ".dll" from the end if it is there
         If Right$(p_ProgId, 1) <> "." Then p_ProgId = p_ProgId & "."   ' Add a "." to the end if it's not there
         p_ProgId = p_ProgId & p_ClassName   ' Concat the classname - this will give us our best guess at the ProgID.
      End If
      
      On Error Resume Next
      ' Attempt to create the obejct with the VB6 intrinsic CreateObject() method that uses the registry.
      ' If it succeeds, then we will be able to debug the source code from external DLL projects when it is running in the IDE.
      ' If it fails, we won't be able to debug the external DLL/Class.
      Set CreateObjectRegfree = CreateObject(p_ProgId)
      On Error GoTo 0
   End If
   
   If CreateObjectRegfree Is Nothing Then
      ' We are either NOT running in the ide, or we couldn't create the object via CreateObject(ProgID)
      ' So we will attempt reg-free instantiation from the compiled DLL.
      
      ' If no folder path info is passed with the DLL name,
      ' then we'll prepend the App\System path to get the full path to the DLL.
      
      ' If a full path or relative path to a different has been passed, we will not prepend anything
      ' because the caller wants to find the DLL at a very precise location.
      
      ' If a relative path to the current foler has been passed,
      ' we will strip the leading ".\" and prepend the folder where the current "image"/file resides.
      
      If InStr(1, p_DllName, "\") < 1 Then
         ' No folders were passed, just a file name. Assume the app's \System\ folder
         ' It's generally not recommended to pass path information unless you know what you're doing, so this is good :)
         p_DllName = PathAppSystem & p_DllName
      
      Else
         ' Some kind of partial path, or full UNC path, or relative path was passed.
         If Left$(p_DllName, 4) = "\\?\" Then
            l_LongPath = True
            p_DllName = Mid$(p_DllName, 5)
         End If
         
         If InStr(1, p_DllName, ":") < 1 Then
            ' Not a drive path
            If Left$(p_DllName, 3) <> "..\" Then
               ' Not a relative path
               If Left$(p_DllName, 2) <> ".\" Then
                  ' Not a relative path
                  If Left$(p_DllName, 2) <> "\\" Then
                     ' Not a short UNC path either
                     If l_LongPath And LCase$(Left$(p_DllName, 4)) = "unc\" Then
                        ' A long UNC path - leave it alone
                     Else
                        ' Assume a path relative to our app's System folder
                        ' and prepend the app system path to the passed partial path
                        p_DllName = PathAppSystem & p_DllName
                        p_DllName = Left$(p_DllName, 2) & Replace$(p_DllName, "\\", "\", 3)
                     End If
                     
                  Else
                     ' Short UNC Path
                     l_ShortUnc = True
                  End If
               
               Else
                  ' A relative path to the current folder.
                  ' We'll assume this means the caller wants to find a DLL in the same path as the current DLL
                  ' So we'l strip the leading ".\" and prepend the folder to the "image" (or DLL file).
                  p_DllName = PathImage & Mid$(p_DllName, 2)
               
               End If
            
            Else
               ' A relative path - not recommended to do this, but we'll leave it alone
            End If
         
         Else
            ' Full path with drive letter, leave the path alone
         End If
      End If
      
      ' Make sure DLL file exists at the path
      If Len(p_DllName) >= MAX_PATH Then l_LongPath = True
      If l_LongPath Then
         If l_ShortUnc Then
            ' We were passed a path starting with "\\", but long path UNC requires a "\\?\UNC\<ServerName>\<ShareName>" format
            ' So we'll strip one of the leading backslashes and prepend "UNC"
            p_DllName = "UNC" & Mid$(p_DllName, 2)
         End If
         ' Finally we'll prepend "\\?\" to the long path
         p_DllName = "\\?\" & p_DllName
      End If
     
      With New_C.FSO
         If Not .FileExists(p_DllName) Then
            ' DLL not found, make sure the passed path has a .DLL extension, and if not we'll add it and try again
            If LCase$(Right$(p_DllName, 4)) <> ".dll" Then
               ' No DLL extension, add it and then look for the DLL again
               p_DllName = p_DllName & ".dll"
                           
               If Not .FileExists(p_DllName) Then
                  ' Still no DLL found, raise an error
                  Err.Raise 53, , "DLL not found at: " & p_DllName
               End If
            End If
         End If
      End With
      
      ' Attempt to create the object using the RC6 registry free GetInstanceEx method.
      
      If l_InIde Then Debug.Print "Attempting to create reg-free '" & p_ClassName & "' object from DLL at: " & p_DllName
      
      Set CreateObjectRegfree = New_C.RegFree.GetInstanceEx(p_DllName, p_ClassName)
   
      If CreateObjectRegfree Is Nothing Then
         If l_InIde Then Debug.Print "FAILED to create reg-free '" & p_ClassName & "' object from DLL at: " & p_DllName
         Err.Raise 429, , "ActiveX Can't create object: " & p_ProgId & " (" & p_DllName & "." & p_ClassName & ")"
         
      Else
         If l_InIde Then Debug.Print "SUCCESSFULLY created reg-free '" & p_ClassName & "' object from DLL at: " & p_DllName
      End If
   End If
End Function

#If UseInlineIdeCheck Then
   ' The MakeTrue method is only required if we are using Vladislav Petrovsky's nifty inline style "In IDE" checks
   Private Function MakeTrue(ByRef p_Var As Boolean) As Boolean
      p_Var = True
      MakeTrue = True
   End Function

#Else
   ' If we aren't using inline In IDE checks, we'll use a more convential RunningInIde function
   ' (caching the result for somewhat improved performance)
   
   Private Function RunningInIde() As Boolean
      ' Returns TRUE if we're running in the IDE
      ' Returns FALSE if we're running as a compiled EXE
      ' Why do we care? It's handy for using reg-free object instantion outside the IDE,
      ' but registry based instantiation inside the IDE (for easier debugging of project groups in particular).
   
      Static s_Checked As Boolean
      Static s_RunningInIde As Boolean
   
      If Not s_Checked Then
         ' Only check if we're in the IDE once
         s_Checked = True
         s_RunningInIde = (App.LogMode = 0)   ' LogMode returns 0 in the IDE
   
         If s_RunningInIde Then Debug.Print "Running in the IDE!"
      End If
   
      RunningInIde = s_RunningInIde ' Return our cached IDE state
   End Function
#End If

Private Function GetModulePath(Optional ByVal p_ModuleHandle As Long = 0, Optional ByVal p_IncludeImageFilename As Boolean = False) As String
   Dim l_Path As String
   Dim l_PathLen As Long
   Dim l_BufferLen As Long
   Dim l_LastDllError As Long
   
   ' Try to get Unicode path using GetModuleFileNameW
   
   ' If no module handle is passed, this will be the path to the folder of the calling EXE process
   ' (even when this module is being called within a separate DLL)
   '    NOTE: When module handle is 0 in the IDE, this will return the folder where the vb6.exe was launched from
   ' If a valid module handle is passed, this will be the path to the image/file where this module is compiled
   '    NOTE: Passing a module handle is useful for an App.Path replacement that is Unicode capable.
   
   ' If p_IncludeImageFilename = True, the EXE/DLL file name will be included in the path.
   ' If p_IncludeImageFilename = False, only the folders will be return with the path (no EXE/DLL filename)
   
   l_BufferLen = MAX_PATH
   
   Do
      l_Path = Space$(l_BufferLen)
      
      l_PathLen = GetModuleFileName(p_ModuleHandle, StrPtr(l_Path), l_BufferLen)
      l_LastDllError = Err.LastDllError
      
      Select Case l_LastDllError
      Case 0
         ' No error, we have our module file path
                 l_Path = Left$(l_Path, l_PathLen)
                 
         If p_IncludeImageFilename Then
            GetModulePath = l_Path
         Else
            GetModulePath = Left$(l_Path, InStrRev(l_Path, "\"))
         End If
         
      Case ERROR_INSUFFICIENT_BUFFER
         ' Buffer was too small - resize and try again
         If l_BufferLen = MAX_LONG_PATH Then
            Err.Raise vbObjectError, , "Could not determine application path with GetModuleFilename. Error #" & l_LastDllError
         End If
         
         l_BufferLen = MAX_LONG_PATH
      
      Case Else
         ' Unexpected error!
         Err.Raise vbObjectError, , "Could not determine application path with GetModuleFilename. Error #" & l_LastDllError
      
      End Select
      
   Loop While (l_LastDllError = ERROR_INSUFFICIENT_BUFFER)
End Function

Public Function PathApp() As String
   ' This function returns the root path of your main app EXE, with a trailing backslash
   
   ' Note that this is different than App.Path that you may be more used to:
   
   '    1) When called from a satellite EXE or DLL in the MyApp\System folder,
   '       App.Path will return the MyApp\System path, whereas PathApp() will return just the MyApp\ folder path.
   
   '    2) App.Path only sometimes includes a trailing backslash, whereas PathApp ALWAYS includes a trailing backslash.
   
   Static s_Path As String
   
   Dim l_Attr As Long
   Dim la_Path() As String
   Dim l_LastDllError As Long
   Dim l_InIde As Boolean
   
#If UseInlineIdeCheck Then
   Debug.Assert MakeTrue(l_InIde)
#Else
   l_InIde = RunningInIde
#End If
   
   If s_Path = vbNullString Then
      ' We haven't built the app path yet, so let's do that
      
      If l_InIde Then
         la_Path = Split(App.Path, "\")
         ReDim Preserve la_Path(UBound(la_Path) - 1)
         s_Path = Join(la_Path, "\") & "\" & App.EXEName & "\"
      
      Else
         ' When not in the IDE, get the path to the folder where the hosting process EXE was launched
         s_Path = GetModulePath

         ' Check if we are running from a satellite EXE in the App\System folder
         ' And adjust the path by stripping the last folder
         
         ' We use the GetFileAttributes API here instead of Dir$() because GFA is Unicode aware.
         ' We also use the GetFileAttributes API instead of New_C.FSO.FileExists
         ' because we haven't bootstrapped RC6.dll/New_C reg-free yet on the first call to PathApp
         ' (since the New_C setup requires a call to PathApp itself)
         ' According to Microsoft, GetFileAttributes returns INVALID_FILE_ATTRIBUTES (-1) if the function fails,
         ' and GetLastError will tell you why.
         ' If we get a result other that INVALID_FILE_ATTRIBUTES that means we detected RC6.dll in the same folder as our host EXE
         ' which means that we are running in a satellite EXE process in the App\System folder, NOT under the main app in the App\ folder
         ' In this case we must adjust our path up one level to point to the main app folder.
         ' Because we always want PathApp to be the absolute/base path of our main App\ folder.
         
         l_Attr = GetFileAttributes(StrPtr(s_Path & "RC6.dll"))
         If l_Attr = INVALID_FILE_ATTRIBUTES Then
            ' We either didn't find the file, or we hit an unexpected error
            
      '     ' If we didn't find the file, this is most likely because RC6.dll is not present in the app path,
            ' BUT it may also be because our app path is very long (>260 characters)
            ' So we'll try to check for RC6.dll using the "\\?\" long-path prefix just in case
            
            l_LastDllError = Err.LastDllError
            
            Select Case l_LastDllError
            Case ERROR_FILE_NOT_FOUND, ERROR_PATH_NOT_FOUND
               ' File/Folder not found -
               ' This could be because it's not there, or it could be failing due to a long path name
               ' If the path is long, we'll try again with the "\\?\" long path prefix to see if that finds anything
               ' If the path isn't long, there's no need to retest here, so we'll continue and assume we haven't found the file.
               
               If Len(s_Path & "RC6.dll") >= MAX_PATH Then
                  ' We have a long path!
                  ' Try again with the "\\?\" prefix
                  ' This will only work if the app/OS is long-file aware
                  
                  l_Attr = GetFileAttributes(StrPtr("\\?\" & s_Path & "RC6.dll"))
                  
                  If l_Attr <> INVALID_FILE_ATTRIBUTES Then
                     ' We found RC6.dll at the long path!
                     ' So clear the error variable
                     l_LastDllError = 0
                  
                  Else
                     ' We have an error (which could just be FILE or FOLDER NOT FOUND)
                     ' Update our error variable
                     l_LastDllError = Err.LastDllError
                  End If
               End If
            
            Case Else
               ' Another type of error occurred. Let's raise our own error since it is unclear how to proceed in this case
               Err.Raise vbObjectError, , "Error determining application folder path. DLL Error: " & l_LastDllError
            
            End Select
         End If
         
         Select Case l_LastDllError
         Case 0   ' No Error
            ' We found a file or folder named RC6.dll
            If Not CBool(l_Attr And (vbDirectory Or vbVolume)) Then
               ' Found a file in our EXE path called RC6.dll
               ' This means we are running a satellite EXE so the app path must be adjusted up one level
               ' To point us to the main MyApp\ folder
               ' This is done so that we can properly build other paths such as PathAppSystem and PathAppSystemRpc
               la_Path = Split(s_Path, "\")
               ReDim Preserve la_Path(UBound(la_Path) - 2)  ' -2 because we have to take the trailing "\" into account
               s_Path = Join(la_Path, "\") & "\"
            
            Else
               ' There's a folder or volume call RC6.dll here???
               ' Not sure what to do here. Please don't name a folder RC6.dll and put it in your main app path. That's just weird ;)
               Err.Raise vbObjectError, , "Bad folder name: RC6.dll"
            End If
            
         Case ERROR_FILE_NOT_FOUND, ERROR_PATH_NOT_FOUND
            ' These are OK errors to have!
            ' The file/path wasn't found - that means we're running an app from our main app folder.
               
         Case Else
            ' Another type of error occurred. Let's raise our own error since it is unclear how to proceed in this case
            Err.Raise vbObjectError, , "Error determining application folder path. DLL Error: " & l_LastDllError
         
         End Select
      End If
      
      If l_InIde Then Debug.Print "Your Main App path is here: " & s_Path
   End If
   
   PathApp = s_Path  ' Return our cached App path
End Function

Public Function PathAppSystem() As String
   ' This is simply the "App\System" folder.
   ' This is where you should store all the RC6 files, plus any additional DLLs that you want to use with your app regfree
   ' You should also store all "satelitte" EXEs used by your main app(s) here instead of in the PathApp folder
   ' so that they are tucked away from your users, keeping the main app folder clean
   ' (making it easier for them to launch the right app EXE)
   
   Static s_Path As String
   
   If s_Path = vbNullString Then
      ' Build and store the path
      s_Path = PathApp & "System\"
   End If
   
   PathAppSystem = s_Path  ' Return our cache App\System path
End Function

Public Function PathAppSystemRpc() As String
   ' This is the "MyApp\System\RpcDlls" folder.
   ' This is where you should store all DLLs that you want to be remotely callable over a network
   ' using RC6 cRpcListener and cRpcConnection objects.
   
   Static s_Path As String
   
   If s_Path = vbNullString Then
      ' Build and store the path
      s_Path = PathAppSystem & "RPCDlls\"
   End If
   
   PathAppSystemRpc = s_Path  ' Return our cache App\System path
End Function

Public Function PathImage(Optional ByVal p_IncludeImageFilename As Boolean = False) As String
   ' This method behaves like the VB6 App.Path by returning the path of the compiled DLL/EXE
   ' that the module code is being executed from.
   
   ' Differences are:
   
   ' 1) It is Unicode compatible
   ' 2) It always includes the trailing backslash
   
   Static s_Path As String
   
   Dim l_Hmodule As Long
   Dim l_Result As Long
   Dim l_FilePath As String
   Dim l_InIde As Boolean
   
#If UseInlineIdeCheck Then
   Debug.Assert MakeTrue(l_InIde)
#Else
   l_InIde = RunningInIde
#End If
   
   If s_Path = vbNullString Then
      If Not l_InIde Then
         ' Only try to get the module handle when running compiled - it always fails in the IDE so we'll just default to App.Path & "\" in the IDE
         l_Result = GetModuleHandleEx(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS Or GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, AddressOf PathApp, l_Hmodule)
         
         If (l_Result <> 0) And (l_Hmodule <> 0) Then
            ' We got a handle, get the path to the module
            l_FilePath = GetModulePath(l_Hmodule, p_IncludeImageFilename)
         End If
      End If
         
      ' If we couldn't get the path from a module handle,
      ' fall back to built-in App.Path method (will be a problem if path is Unicode, but should be OK most of the time)
      If l_FilePath = vbNullString Then l_FilePath = App.Path
      
      ' Make sure we have a trailing backslash
      If Right$(l_FilePath, 1) <> "\" Then l_FilePath = l_FilePath & "\"
      
      ' Cache the path so we can skip all of this work on subsequent passes - the image path should never change while it is executing
      s_Path = l_FilePath
   End If
   
   PathImage = s_Path
End Function


