Attribute VB_Name = "modMath"
Option Explicit

Public Function mathMaxLong(p_Num1 As Long, p_Num2 As Long) As Long
   If p_Num1 > p_Num2 Then
      mathMaxLong = p_Num1
   Else
      mathMaxLong = p_Num2
   End If
End Function

Public Function mathMinLong(p_Num1 As Long, p_Num2 As Long) As Long
   If p_Num1 < p_Num2 Then
      mathMinLong = p_Num1
   Else
      mathMinLong = p_Num2
   End If
End Function

