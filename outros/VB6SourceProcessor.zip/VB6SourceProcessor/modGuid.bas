Attribute VB_Name = "modGuid"
Option Explicit

Public Function guidCreate() As String
   Static so_Lib As CGuidBase36
   
   If so_Lib Is Nothing Then Set so_Lib = New CGuidBase36
   guidCreate = so_Lib.GenerateRandomCode
End Function


