VERSION 5.00
Object = "{7020C36F-09FC-41FE-B822-CDE6FBB321EB}#1.2#0"; "vbccr18.OCX"
Begin VB.Form frmConfirmRun 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Confirm Action"
   ClientHeight    =   4180
   ClientLeft      =   30
   ClientTop       =   370
   ClientWidth     =   5370
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4180
   ScaleWidth      =   5370
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin vbccr18.CommandLink cmdCancel 
      Cancel          =   -1  'True
      Height          =   940
      Left            =   330
      TabIndex        =   1
      Top             =   2850
      Width           =   4780
      _ExtentX        =   8431
      _ExtentY        =   1658
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "frmConfirmRun.frx":0000
      Hint            =   "frmConfirmRun.frx":002E
   End
   Begin vbccr18.CommandLink cmdConfirm 
      Height          =   1150
      Left            =   330
      TabIndex        =   0
      Top             =   1590
      Width           =   4630
      _ExtentX        =   8167
      _ExtentY        =   2028
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Enabled         =   0   'False
      Caption         =   "frmConfirmRun.frx":00B0
      Hint            =   "frmConfirmRun.frx":0100
   End
   Begin vbccr18.LabelW lblWarning2 
      Height          =   820
      Left            =   780
      TabIndex        =   3
      Top             =   690
      Width           =   3970
      _ExtentX        =   7003
      _ExtentY        =   1446
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   $"frmConfirmRun.frx":01D2
      WordWrap        =   -1  'True
   End
   Begin vbccr18.LabelW lblWarning 
      Height          =   340
      Left            =   750
      TabIndex        =   2
      Top             =   150
      Width           =   3610
      _ExtentX        =   6368
      _ExtentY        =   600
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   14
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   16711935
      Caption         =   "WARNING!"
   End
End
Attribute VB_Name = "frmConfirmRun"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private WithEvents mo_Timer As RC6.cTimer
Attribute mo_Timer.VB_VarHelpID = -1

Private m_TimerTicks As Long

Public UnloadMode As VBA.VbMsgBoxResult

Private Sub cmdCancel_Click()
   Me.UnloadMode = vbCancel
   Me.Hide
End Sub

Private Sub cmdConfirm_Click()
   Me.UnloadMode = vbOK
   Me.Hide
End Sub

Private Sub Form_Load()
   If optRunConfirmationSeconds > 0 Then
      Me.cmdConfirm.Caption = Me.cmdConfirm.Caption & " (" & optRunConfirmationSeconds & ")."
   
      Set mo_Timer = New_c.Timer(1000, True)
   Else
      With Me.cmdConfirm
         .Caption = .Caption & "."
         .Enabled = True
      End With
   End If
End Sub

Private Sub mo_Timer_Timer()
   mo_Timer.Enabled = False
   
   m_TimerTicks = m_TimerTicks + 1
   
   If m_TimerTicks < optRunConfirmationSeconds Then
      Me.cmdConfirm.Caption = "Run the source processor (" & optRunConfirmationSeconds - m_TimerTicks & ")."
   Else
      Me.cmdConfirm.Caption = "Run the source processor."
      Me.cmdConfirm.Enabled = True
   End If
   
   mo_Timer.Enabled = Not Me.cmdConfirm.Enabled
End Sub
