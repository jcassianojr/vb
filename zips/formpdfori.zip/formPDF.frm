VERSION 5.00
Object = "{BDF6FCF6-E2A0-4DA6-8DF8-FA27594705C8}#26.1#0"; "XpControls.ocx"
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.1#0"; "BSPrin10.ocx"
Object = "{379157C5-E9BD-43F1-9F83-B037496BED42}#1.1#0"; "vbccr18.ocx"
Begin VB.Form formConvertToPDF 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Text-PDF v1.0"
   ClientHeight    =   5025
   ClientLeft      =   2625
   ClientTop       =   1395
   ClientWidth     =   9345
   Icon            =   "formPDF.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5025
   ScaleWidth      =   9345
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   7200
      Top             =   4080
      _ExtentX        =   1191
      _ExtentY        =   1191
   End
   Begin XPControls.XPButton btnConvert 
      Height          =   555
      Left            =   6960
      TabIndex        =   24
      Top             =   0
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   979
      Picture         =   "formPDF.frx":08CA
      Caption         =   "Criar Pdf (Conversor)"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.CheckBox ChkPaisagem 
      Caption         =   "Paisagem"
      Height          =   255
      Left            =   5160
      TabIndex        =   18
      Top             =   2400
      Width           =   1455
   End
   Begin VBCCR18.ComboBoxW cmbPageSize 
      Height          =   315
      Left            =   3720
      TabIndex        =   17
      Top             =   2400
      Width           =   1305
      _ExtentX        =   0
      _ExtentY        =   0
      Style           =   2
   End
   Begin VBCCR18.ComboBoxW cmbFontSize 
      Height          =   315
      Left            =   2280
      TabIndex        =   15
      Top             =   2400
      Width           =   690
      _ExtentX        =   0
      _ExtentY        =   0
      Style           =   2
   End
   Begin VBCCR18.ComboBoxW cmbRotation 
      Height          =   315
      Left            =   3000
      TabIndex        =   16
      Top             =   2400
      Width           =   690
      _ExtentX        =   0
      _ExtentY        =   0
      Style           =   2
   End
   Begin VBCCR18.ComboBoxW cmbFont 
      Height          =   315
      Left            =   120
      TabIndex        =   14
      Top             =   2400
      Width           =   2055
      _ExtentX        =   0
      _ExtentY        =   0
      Style           =   2
   End
   Begin VB.TextBox txtTitle 
      Height          =   375
      Left            =   1470
      TabIndex        =   9
      Top             =   1920
      Width           =   5100
   End
   Begin VB.TextBox txtOutputFile 
      Height          =   345
      Left            =   120
      TabIndex        =   13
      Top             =   4320
      Width           =   6480
   End
   Begin VB.TextBox txtFilename 
      Height          =   345
      Left            =   120
      TabIndex        =   11
      Top             =   3360
      Width           =   6480
   End
   Begin VB.TextBox txtSubject 
      Height          =   375
      Left            =   1440
      TabIndex        =   7
      Top             =   1440
      Width           =   5100
   End
   Begin VB.TextBox txtKeywords 
      Height          =   375
      Left            =   1440
      TabIndex        =   5
      Top             =   960
      Width           =   5100
   End
   Begin VB.TextBox txtCreator 
      Height          =   375
      Left            =   1440
      TabIndex        =   3
      Top             =   480
      Width           =   5100
   End
   Begin VB.TextBox txtAuthor 
      Height          =   375
      Left            =   1470
      TabIndex        =   1
      Top             =   45
      Width           =   5100
   End
   Begin XPControls.XPButton CmdVisua 
      Height          =   435
      Left            =   6960
      TabIndex        =   19
      Top             =   1800
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   767
      Picture         =   "formPDF.frx":0E64
      Caption         =   "Visualizar"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton btnClose 
      Height          =   435
      Left            =   6960
      TabIndex        =   20
      Top             =   3480
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   767
      Picture         =   "formPDF.frx":13FE
      Caption         =   "Retornar"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton btnSave 
      Height          =   435
      Left            =   1800
      TabIndex        =   21
      Top             =   3840
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   767
      Picture         =   "formPDF.frx":1998
      Caption         =   "Salvar &PDF Como"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton btnOpen 
      Height          =   435
      Left            =   1920
      TabIndex        =   22
      Top             =   2880
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   767
      Picture         =   "formPDF.frx":1F32
      Caption         =   "Abrir"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton CmdSendMail 
      Height          =   435
      Left            =   6960
      TabIndex        =   23
      Top             =   2400
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   767
      Picture         =   "formPDF.frx":24CC
      Caption         =   "EnviarEmail"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton CmdAbrirCom 
      Height          =   435
      Left            =   3360
      TabIndex        =   25
      TabStop         =   0   'False
      Top             =   2880
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   767
      Picture         =   "formPDF.frx":2A66
      Caption         =   "Abrir Com"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton cmdPreviewOrigem 
      Height          =   435
      Left            =   4800
      TabIndex        =   26
      Top             =   2880
      Width           =   1875
      _ExtentX        =   3307
      _ExtentY        =   767
      Picture         =   "formPDF.frx":3000
      Caption         =   "Visualizar Origem"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton cmdimp 
      Height          =   435
      Left            =   6960
      TabIndex        =   27
      Top             =   2880
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   767
      Picture         =   "formPDF.frx":359A
      Caption         =   "Imprimir"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton CmdGeraPorPreview 
      Height          =   555
      Left            =   6960
      TabIndex        =   28
      Top             =   600
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   979
      Picture         =   "formPDF.frx":3B34
      Caption         =   "Cria Pdf   (Preview)"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin XPControls.XPButton CmdAbrirPdf 
      Height          =   435
      Left            =   6960
      TabIndex        =   29
      Top             =   1320
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   767
      Picture         =   "formPDF.frx":40CE
      Caption         =   "Abrir"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Label lblTitle 
      Alignment       =   1  'Right Justify
      Caption         =   "Titulo:"
      Height          =   255
      Left            =   150
      TabIndex        =   8
      Top             =   1950
      Width           =   1230
   End
   Begin VB.Label lblOutputFile 
      Caption         =   "Arquivo Destino"
      Height          =   225
      Left            =   120
      TabIndex        =   12
      Top             =   3840
      Width           =   1215
   End
   Begin VB.Label lblFilename 
      Caption         =   "Arquivo para converter"
      Height          =   240
      Left            =   120
      TabIndex        =   10
      Top             =   2880
      Width           =   1695
   End
   Begin VB.Label lblSubject 
      Alignment       =   1  'Right Justify
      Caption         =   "Assunto:"
      Height          =   255
      Left            =   150
      TabIndex        =   6
      Top             =   1470
      Width           =   1230
   End
   Begin VB.Label lblKeyword 
      Alignment       =   1  'Right Justify
      Caption         =   "Palavras Chave:"
      Height          =   255
      Left            =   150
      TabIndex        =   4
      Top             =   1005
      Width           =   1230
   End
   Begin VB.Label lblCreator 
      Alignment       =   1  'Right Justify
      Caption         =   "Autor:"
      Height          =   255
      Left            =   150
      TabIndex        =   2
      Top             =   540
      Width           =   1230
   End
   Begin VB.Label lblAuthor 
      Alignment       =   1  'Right Justify
      Caption         =   "Nome"
      Height          =   255
      Left            =   150
      TabIndex        =   0
      Top             =   90
      Width           =   1230
   End
End
Attribute VB_Name = "formConvertToPDF"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim Position As Long
Dim pageNo As Long
Dim lineNo As Long
Dim pageHeight As Long
Dim pageWidth As Long
Dim location(1 To 5000) As Long
Dim pageObj(1 To 5000) As Long
Dim LINES As Long
Dim Obj As Long
Dim Tpages As Long
Dim encoding As Long
Dim resources As Long
'Dim Pages As Variant
Dim author As String
Dim creator As String
Dim keywords As String
Dim subject As String
Dim Title As String
Dim BaseFont As String
Dim pointSize As Currency
Dim vertSpace As Currency
Dim rotate As Integer
Dim info As Long
Dim root As Long
Dim npagex As Double
Dim npagey As Long
Dim filetxt As String
Dim filepdf As String
Dim linelen As Long
Dim cache As String
'Dim cmdline As String

Const AppName = "Text-PDF v1.0"

Private Sub CmdAbrirCom_Click()
  If FileConnExist(txtFilename.Text, True) Then
    Call OpenWith(txtFilename.Text, OAIF_ALLOW_REGISTRATION Or OAIF_EXEC Or OAIF_FORCE_REGISTRATION, CLng(Me.hwnd))
  End If
End Sub

Private Sub CmdAbrirPdf_Click()
  Dim cARQSHELL As String
  cARQSHELL = FixStr(txtOutputFile.Text)
  If FileConnExist(cARQSHELL) Then
    ShellEx cARQSHELL, essSW_SHOWDEFAULT, , , , CLng(Me.hwnd)
  End If
End Sub

Private Sub CmdGeraPorPreview_Click()
 If PrintPreview1.PrinterExists("Microsoft Print to PDF") Then
        PrintPreview1.ShowSaveToFile "Microsoft Print to PDF", "*.pdf"
        If PrintPreview1.Canceled Then
            MsgBox "Error, could not save the file, check if to are allowed to write at that location", vbExclamation
            Exit Sub
        End If
    Else
        MsgBox "'Microsoft Print to PDF' driver is not installed.", vbExclamation
        Exit Sub
    End If
btnfalse
End Sub

Private Sub cmdimp_Click()
  Dim cARQSHELL As String
  cARQSHELL = FixStr(txtOutputFile.Text)
  If FileConnExist(cARQSHELL) Then
    ShellEx cARQSHELL, essSW_SHOWDEFAULT, , , "print", CLng(Me.hwnd)
  End If
End Sub

Private Sub cmdPreviewOrigem_Click()
  PrintPreview1.ShowPreview
End Sub

Public Sub PrintPreview1_PrepareReport(Cancel As Boolean)
  MyPrintingTXT
End Sub

Private Sub CmdSendMail_Click()
  Dim cARQUIVO As String
  cARQUIVO = FixStr(txtOutputFile.Text)
  'servidor,porta,from,to,assunto,anexos,mensagem,enviar e sair
  ePASS01 = Array("", _
                  "", _
                  "", _
                  "", _
                  "", _
                  cARQUIVO, _
                  "", _
                  False)
  FrmSendMail.Show vbModal, Me
End Sub

Private Sub CmdVisua_Click()
 cARQRTF = FixStr(txtOutputFile.Text)
 FrmPreview.Show vbModal, Me
End Sub

Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
  TeclaEnter KeyCode
End Sub
Private Sub Form_Load()

  CenterFormToScreen Me
  cmbFont.ListIndex = 1                        ' 10
  cmbFontSize.ListIndex = 0
  cmbRotation.ListIndex = 0
  cmbPageSize.ListIndex = 0

  txtCreator.Text = zNOMEFOLHA



  If Len(ePASS01) > 0 Then
    If FileConnExist(ePASS01) Then
      txtTitle.Text = NomeArq(ePASS01, True)
      txtFilename.Text = ePASS01
      txtOutputFile.Text = TrocaExt(ePASS01, "PDF")
      btnOpen.Enabled = False
      txtFilename.Enabled = False
    End If
  End If
  PrintPreview1.AuxiliaryButtonVisible = PrintPreview1.PrinterExists("Microsoft Print to PDF")
  PrintPreview1.AuxiliaryButtonToolTipText = "Salvar como PDF"
  CmdVisua.Enabled = False
  CmdSendMail.Enabled = False
  cmdimp.Enabled = False
  CmdAbrirPdf.Enabled = False


  
End Sub
Public Sub PrintPreview1_AuxiliaryButtonClick(UpdateReport As Boolean)
  PrintPreview1.ShowSaveToFile "Microsoft Print to PDF", "*.pdf"
  UpdateReport = False  ' we don't need to update the report in the Print preview window after this action (the default value of UpdateReport parameter is True)
End Sub
Private Sub txtAuthor_GotFocus()
  txtAuthor.SelStart = 0
  txtAuthor.SelLength = Len(txtAuthor.Text)
End Sub
Private Sub txtCreator_GotFocus()
  txtCreator.SelStart = 0
  txtCreator.SelLength = Len(txtCreator.Text)
End Sub

Private Sub txtSubject_GotFocus()
  txtSubject.SelStart = 0
  txtSubject.SelLength = Len(txtSubject.Text)
End Sub

Private Sub txtTitle_GotFocus()
  txtTitle.SelStart = 0
  txtTitle.SelLength = Len(txtTitle.Text)
End Sub

Private Sub txtKeywords_GotFocus()
  txtKeywords.SelStart = 0
  txtKeywords.SelLength = Len(txtKeywords.Text)
End Sub

Private Sub txtFilename_GotFocus()
  txtFilename.SelStart = 0
  txtFilename.SelLength = Len(txtFilename.Text)
End Sub

Private Sub txtOutputFile_GotFocus()
  txtOutputFile.SelStart = 0
  txtOutputFile.SelLength = Len(txtOutputFile.Text)
End Sub

Private Sub btnClose_Click()
  Unload Me
End Sub

Private Sub btnOpen_Click()
  On Local Error Resume Next
  txtFilename.Text = OpenArqExt(Me, txtFilename.Text, "txt", "Arquivos txt")

  If Not Len(txtFilename.Text) = 0 Then
    txtOutputFile.Text = TrocaExt(txtFilename.Text, "pdf")
  End If


End Sub

Private Sub btnSave_Click()
  Dim sFILTER As String
  Dim FileName As String
  sFILTER = "Arquivos PDF (*.PDF)" & vbNullChar & "*.PDF" & vbNullChar & "Todos Arquivo" & vbNullChar & "*.*"
  FileName = FileSave(Me, sFILTER, 1, "PDF", cARQRTF, cARQRTF, "Salvar PDF")
  If Not Len(FileName) = 0 Then
    txtOutputFile.Text = FileName
  End If
End Sub

Private Sub btnSource_Click()
  On Local Error Resume Next
End Sub
Private Sub btnfalse()
      CmdVisua.Enabled = True
       CmdSendMail.Enabled = True
       cmdimp.Enabled = True
       CmdAbrirPdf.Enabled = True
       btnConvert.Enabled = False
       btnSave.Enabled = False
       CmdGeraPorPreview.Enabled = False
       txtOutputFile.Enabled = False
End Sub
Private Sub btnConvert_Click()
  If txtFilename.Text <> "" And txtOutputFile.Text <> "" Then
    ConvertToPDF txtFilename.Text, txtOutputFile.Text, _
                 txtAuthor.Text, txtCreator.Text, txtKeywords.Text, _
                 txtSubject.Text, txtTitle.Text, _
                 cmbFont.Text, Val(cmbFontSize.Text), Val(cmbRotation.Text), _
                 Val(cmbPageSize.Text), Val(Right(cmbPageSize.Text, 3)), ChkPaisagem.Value
    If FileConnExist(txtOutputFile.Text) Then
      Alert "Conversao Concluida"
      btnfalse
    End If
  Else
    MsgBox "Informe o nome do arquivo."
  End If
End Sub

Public Function ConvertToPDF(FileName As String, outputfile As String, _
                             Optional TextAuthor As String, Optional TextCreator As String, Optional TextKeywords As String, _
                             Optional TextSubject As String, Optional TextTitle As String, _
                             Optional FontName As String = "Courier", Optional FontSize As Integer = 10, Optional Rotation As Integer, _
                             Optional pwidth As Single = 8.5, Optional pheight As Single = 11, _
                             Optional lPAISAGEM As Boolean = False)

  Dim tpwidth As Long
  Dim tpheight As Long
  On Error GoTo er
  If Not FileConnExist(FileName) Then
    MsgBox "Arquivo '" & FileName & "' n�o existe."
    Exit Function
  ElseIf FileConnExist(outputfile) Then
    If MDG("Arquivo Ja Existente" & outputfile, "Confirma Exclusao") Then
      DeleteFile outputfile  'Kill outputfile
    End If
  End If

  If lPAISAGEM Then
    tpwidth = pwidth
    tpheight = pheight
    pwidth = tpheight
    pheight = tpwidth
  End If


  initialize FontName, FontSize, Rotation, pwidth, pheight

  author = TextAuthor
  creator = TextCreator
  keywords = TextKeywords
  subject = TextSubject
  Title = TextTitle
  filetxt = FileName
  filepdf = outputfile

  Call WriteStart
  Call WriteHead
  Call WritePages
  Call endpdf
  Exit Function
er:
  MsgBox Err.Description
End Function

Private Sub initialize(FontName As String, FontSize As Integer, Rotation As Integer, pwidth As Single, pheight As Single)
  pageHeight = 72 * pheight
  pageWidth = 72 * pwidth

  BaseFont = FontName                          ' Courier, Times-Roman, Arial
  pointSize = FontSize                         ' Font Size; n�o altere
  vertSpace = FontSize * 1.2                   ' Vertical spacing
  rotate = Rotation                            ' degrees to rotate; try setting 90,180,etc
  LINES = (pageHeight - 72) / vertSpace        ' no of lines on one page

  Select Case LCase(FontName)
  Case "courier": linelen = 1.5 * pageWidth / pointSize
  Case "arial": linelen = 2 * pageWidth / pointSize
    'Case "Times-Roman": linelen = 2.2 * pageWidth / pointSize
  Case Else: linelen = 2.2 * pageWidth / pointSize
  End Select

  Obj = 0
  npagex = pageWidth / 2
  npagey = 25
  pageNo = 0
  Position = 0
  cache = ""
End Sub

Private Sub writepdf(stre As String, Optional flush As Boolean)
  On Local Error Resume Next
  Position = Position + Len(stre)
  cache = cache & stre & vbCr
  If Len(cache) > 32000 Or flush Then
    Open filepdf For Append As #1
    Print #1, cache;
    Close #1
    cache = ""
  End If
End Sub

Private Sub WriteStart()
  writepdf ("%PDF-1.2")
  writepdf ("%����")
End Sub

Private Sub WriteHead()
  Dim CreationDate As String
  On Error GoTo er
  CreationDate = "D:" & Format(Now, "YYYYMMDDHHNNSS")
  Obj = Obj + 1
  location(Obj) = Position
  info = Obj

  writepdf (Obj & " 0 obj")
  writepdf ("<<")
  writepdf ("/Author (" & author & ")")
  writepdf ("/CreationDate (" & CreationDate & ")")
  writepdf ("/Creator (" & creator & ")")
  writepdf ("/Producer (" & AppName & ")")
  writepdf ("/Title (" & Title & ")")
  writepdf ("/Subject (" & subject & ")")
  writepdf ("/Keywords (" & keywords & ")")
  writepdf (">>")
  writepdf ("endobj")

  Obj = Obj + 1
  root = Obj
  Obj = Obj + 1
  Tpages = Obj
  encoding = Obj + 2
  resources = Obj + 3

  Obj = Obj + 1
  location(Obj) = Position
  writepdf (Obj & " 0 obj")
  writepdf ("<<")
  writepdf ("/Type /Font")
  writepdf ("/Subtype /Type1")
  writepdf ("/Name /F1")
  writepdf ("/Encoding " & encoding & " 0 R")
  writepdf ("/BaseFont /" & BaseFont)
  writepdf (">>")
  writepdf ("endobj")

  Obj = Obj + 1
  location(Obj) = Position
  writepdf (Obj & " 0 obj")
  writepdf ("<<")
  writepdf ("/Type /Encoding")
  writepdf ("/BaseEncoding /WinAnsiEncoding")
  writepdf (">>")
  writepdf ("endobj")

  Obj = Obj + 1
  location(Obj) = Position
  writepdf (Obj & " 0 obj")
  writepdf ("<<")
  writepdf ("  /Font << /F1 " & Obj - 2 & " 0 R >>")
  writepdf ("  /ProcSet [ /PDF /Text ]")
  writepdf (">>")
  writepdf ("endobj")
  Exit Sub
er:
  MsgBox Err.Description
End Sub

Private Sub WritePages()
  Dim i As Integer
  Dim line As String
  Dim tmpline As String
  Dim beginstream As String
  On Error GoTo er
  Open filetxt For Input As #2
  beginstream = StartPage
  lineNo = -1
  Do Until EOF(2)
    Line Input #2, line
    lineNo = lineNo + 1

    'quebra de p�gina
    If lineNo >= LINES Or InStr(line, Chr(12)) > 0 Then
      writepdf ("1 0 0 1 " & npagex & " " & npagey & " Tm")
      writepdf ("(" & pageNo & ") Tj")
      writepdf ("/F1 " & pointSize & " Tf")
      endpage (beginstream)
      beginstream = StartPage
    End If

    line = ReplaceText(ReplaceText(line, "(", "\("), ")", "\)")
    line = Trim(line)

    If Len(line) > linelen Then

      'quebra de linha
      Do While Len(line) > linelen
        tmpline = Left(line, linelen)
        For i = Len(tmpline) To Len(tmpline) \ 2 Step -1
          If InStr("*&^%$#,. ;<=>[])}!""", Mid(tmpline, i, 1)) Then
            tmpline = Left(tmpline, i)
            Exit For
          End If
        Next

        line = Mid$(line, Len(tmpline) + 1)
        writepdf ("T* (" & tmpline & vbCrLf & ") Tj")
        lineNo = lineNo + 1

        'quebra de p�gina
        If lineNo >= LINES Or InStr(line, Chr(12)) > 0 Then
          writepdf ("1 0 0 1 " & npagex & " " & npagey & " Tm")
          writepdf ("(" & pageNo & ") Tj")
          writepdf ("/F1 " & pointSize & " Tf")
          endpage (beginstream)
          beginstream = StartPage
        End If
      Loop

      lineNo = lineNo + 1
      writepdf ("T* (" & line & vbCrLf & ") Tj")

    Else

      writepdf ("T* (" & line & vbCrLf & ") Tj")

    End If
  Loop
  Close #2
  writepdf ("1 0 0 1 " & npagex & " " & npagey & " Tm")
  writepdf ("(" & pageNo & ") Tj")
  writepdf ("/F1 " & pointSize & " Tf")
  endpage (beginstream)
  Exit Sub
er:
  MsgBox Err.Description
  Close
End Sub

Private Function StartPage() As String
  Dim strmpos As Long
  On Error GoTo er
  Obj = Obj + 1
  location(Obj) = Position
  pageNo = pageNo + 1
  pageObj(pageNo) = Obj

  writepdf (Obj & " 0 obj")
  writepdf ("<<")
  writepdf ("/Type /Page")
  writepdf ("/Parent " & Tpages & " 0 R")
  writepdf ("/Resources " & resources & " 0 R")
  Obj = Obj + 1
  writepdf ("/Contents " & Obj & " 0 R")
  writepdf ("/Rotate " & rotate)
  writepdf (">>")
  writepdf ("endobj")

  location(Obj) = Position
  writepdf (Obj & " 0 obj")
  writepdf ("<<")
  writepdf ("/Length " & Obj + 1 & " 0 R")
  writepdf (">>")
  writepdf ("stream")
  strmpos = Position
  writepdf ("BT")
  writepdf ("/F1 " & pointSize & " Tf")
  writepdf ("1 0 0 1 50 " & pageHeight - 40 & " Tm")
  writepdf (vertSpace & " TL")

  StartPage = strmpos
  Exit Function
er:
  MsgBox Err.Description
End Function

Function endpage(streamstart As Long) As String
  Dim streamEnd As Long
  On Error GoTo er
  writepdf ("ET")
  streamEnd = Position
  writepdf ("endstream")
  writepdf ("endobj")
  Obj = Obj + 1
  location(Obj) = Position
  writepdf (Obj & " 0 obj")
  writepdf (streamEnd - streamstart)
  writepdf "endobj"
  lineNo = 0
  Exit Function
er:
  MsgBox Err.Description
End Function

Sub endpdf()
  Dim ty As String
  Dim i As Integer
  Dim xreF As Long
  
  On Error GoTo er
  location(root) = Position
  writepdf (root & " 0 obj")
  writepdf ("<<")
  writepdf ("/Type /Catalog")
  writepdf ("/Pages " & Tpages & " 0 R")
  writepdf (">>")
  writepdf ("endobj")
  location(Tpages) = Position
  writepdf (Tpages & " 0 obj")
  writepdf ("<<")
  writepdf ("/Type /Pages")
  writepdf ("/Count " & pageNo)
  writepdf ("/MediaBox [ 0 0 " & pageWidth & " " & pageHeight & " ]")
  ty = ("/Kids [ ")
  For i = 1 To pageNo
    ty = ty & pageObj(i) & " 0 R "
  Next i
  ty = ty & "]"
  writepdf (ty)
  writepdf (">>")
  writepdf ("endobj")
  xreF = Position
  writepdf ("0 " & Obj + 1)
  writepdf ("0000000000 65535 f ")
  For i = 1 To Obj
    writepdf (Format(location(i), "0000000000") & " 00000 n ")
  Next i
  writepdf ("trailer")
  writepdf ("<<")
  writepdf ("/Size " & Obj + 1)
  writepdf ("/Root " & root & " 0 R")
  writepdf ("/Info " & info & " 0 R")
  writepdf (">>")
  writepdf ("startxref")
  writepdf (xreF)
  writepdf "%%EOF", True
  Exit Sub
er:
  MsgBox Err.Description
End Sub

Public Function ReplaceText(Text As String, TextToReplace As String, NewText As String) As String
  Dim mtext As String
  Dim SpacePos As Long
  mtext = Text
  SpacePos = InStr(mtext, TextToReplace)
  Do While SpacePos
    mtext = Left(mtext, SpacePos - 1) & NewText & Mid(mtext, SpacePos + Len(TextToReplace))
    SpacePos = InStr(SpacePos + Len(NewText), mtext, TextToReplace)
  Loop
  ReplaceText = mtext
End Function
Public Sub MyPrintingTXT()
  Dim fileFile As Integer
  Dim STRBUFFER As String
  Dim cARQOPEN As String
  cARQOPEN = txtFilename.Text
  If Not FileConnExist(cARQOPEN, True) Then
    Exit Sub
  End If
  fileFile = FreeFile
  Open cARQOPEN For Input As #fileFile
  Do While Not EOF(fileFile)
    'read line
    Input #fileFile, STRBUFFER
    Printer.Print STRBUFFER
  Loop
  Close fileFile
End Sub

